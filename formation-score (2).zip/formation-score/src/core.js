/* 동선 악보 — core logic (pure functions, no DOM).
   Stage coordinates: x 0 = stage left as seen from the audience, 1 = right.
                      y 0 = back of stage (upstage), 1 = front (downstage, near audience). */
(function (G) {
  'use strict';

  // ---------- geometry ----------
  function solve(A, b) {
    const n = b.length;
    const M = A.map((r, i) => r.concat([b[i]]));
    for (let c = 0; c < n; c++) {
      let p = c;
      for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (Math.abs(M[p][c]) < 1e-12) return null;
      [M[c], M[p]] = [M[p], M[c]];
      for (let r = 0; r < n; r++) {
        if (r === c) continue;
        const f = M[r][c] / M[c][c];
        for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
      }
    }
    return M.map((r, i) => r[n] / r[i]);
  }

  // 4 point correspondences -> 3x3 homography (row-major array of 9)
  function homography(src, dst) {
    const A = [], b = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i], [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
    }
    const h = solve(A, b);
    return h ? h.concat([1]) : null;
  }
  function applyH(H, x, y) {
    const w = H[6] * x + H[7] * y + H[8];
    return [(H[0] * x + H[1] * y + H[2]) / w, (H[3] * x + H[4] * y + H[5]) / w];
  }
  function invertH(m) {
    const [a, b, c, d, e, f, g, h, i] = m;
    const A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
    const det = a * A + b * B + c * C;
    if (Math.abs(det) < 1e-12) return null;
    return [A, -(b * i - c * h), b * f - c * e, B, a * i - c * g, -(a * f - c * d), C, -(a * h - b * g), a * e - b * d].map(v => v / det);
  }
  const UNIT = [[0, 0], [1, 0], [1, 1], [0, 1]]; // back-left, back-right, front-right, front-left

  // ---------- YOLOv8 output decoding ----------
  // data: Float32Array [84 * 8400]; letterbox params map 640-space back to video pixels
  function decodeYolo(data, lb, confTh) {
    const N = data.length / 84, out = []; // 8400 anchors at 640 px input, fewer at smaller sizes
    for (let i = 0; i < N; i++) {
      const s = data[4 * N + i]; // class 0 = person
      if (s < confTh) continue;
      const cx = data[i], cy = data[N + i], w = data[2 * N + i], h = data[3 * N + i];
      out.push({
        x1: (cx - w / 2 - lb.padX) / lb.scale, y1: (cy - h / 2 - lb.padY) / lb.scale,
        x2: (cx + w / 2 - lb.padX) / lb.scale, y2: (cy + h / 2 - lb.padY) / lb.scale, score: s
      });
    }
    return nms(out, 0.5);
  }
  // YOLOv8-pose output: [56 x N] = box (4), person score (1), 17 keypoints (x, y, visibility)
  function decodePose(data, lb, confTh) {
    const N = data.length / 56, out = [];
    for (let i = 0; i < N; i++) {
      const s = data[4 * N + i];
      if (s < confTh) continue;
      const cx = data[i], cy = data[N + i], w = data[2 * N + i], h = data[3 * N + i];
      const kp = [];
      for (let j = 0; j < 17; j++) kp.push([(data[(5 + 3 * j) * N + i] - lb.padX) / lb.scale, (data[(6 + 3 * j) * N + i] - lb.padY) / lb.scale, data[(7 + 3 * j) * N + i]]);
      out.push({ x1: (cx - w / 2 - lb.padX) / lb.scale, y1: (cy - h / 2 - lb.padY) / lb.scale, x2: (cx + w / 2 - lb.padX) / lb.scale, y2: (cy + h / 2 - lb.padY) / lb.scale, score: s, kp });
    }
    return nms(out, 0.5);
  }
  function iou(a, b) {
    const ix = Math.max(0, Math.min(a.x2, b.x2) - Math.max(a.x1, b.x1));
    const iy = Math.max(0, Math.min(a.y2, b.y2) - Math.max(a.y1, b.y1));
    const I = ix * iy, U = (a.x2 - a.x1) * (a.y2 - a.y1) + (b.x2 - b.x1) * (b.y2 - b.y1) - I;
    return U > 0 ? I / U : 0;
  }
  function nms(boxes, th) {
    boxes.sort((a, b) => b.score - a.score);
    const keep = [];
    for (const b of boxes) if (keep.every(k => iou(k, b) < th)) keep.push(b);
    return keep;
  }

  // ---------- Hungarian assignment (rows <= cols handled by padding) ----------
  function hungarian(cost) {
    const n = cost.length, m = cost[0] ? cost[0].length : 0, N = Math.max(n, m);
    if (!n || !m) return new Array(n).fill(-1);
    const BIG = 1e6;
    const a = [];
    for (let i = 0; i < N; i++) { a.push([]); for (let j = 0; j < N; j++) a[i].push(i < n && j < m ? cost[i][j] : BIG); }
    const u = new Array(N + 1).fill(0), v = new Array(N + 1).fill(0), p = new Array(N + 1).fill(0), way = new Array(N + 1).fill(0);
    for (let i = 1; i <= N; i++) {
      p[0] = i; let j0 = 0;
      const minv = new Array(N + 1).fill(Infinity), used = new Array(N + 1).fill(false);
      do {
        used[j0] = true; const i0 = p[j0]; let delta = Infinity, j1 = 0;
        for (let j = 1; j <= N; j++) if (!used[j]) {
          const cur = a[i0 - 1][j - 1] - u[i0] - v[j];
          if (cur < minv[j]) { minv[j] = cur; way[j] = j0; }
          if (minv[j] < delta) { delta = minv[j]; j1 = j; }
        }
        for (let j = 0; j <= N; j++) { if (used[j]) { u[p[j]] += delta; v[j] -= delta; } else minv[j] -= delta; }
        j0 = j1;
      } while (p[j0] !== 0);
      do { const j1 = way[j0]; p[j0] = p[j1]; j0 = j1; } while (j0);
    }
    const res = new Array(n).fill(-1);
    for (let j = 1; j <= N; j++) if (p[j] && p[j] - 1 < n && j - 1 < m && a[p[j] - 1][j - 1] < BIG) res[p[j] - 1] = j - 1;
    return res;
  }

  // ---------- frames -> stage points ----------
  // frames: [{t, dets:[{x1,y1,x2,y2,score}]}]  (video pixel space)
  function stagePoints(frames, H, margin) {
    margin = margin == null ? 0.08 : margin;
    return frames.map(f => ({
      t: f.t,
      pts: f.dets.map(d => {
        const ix = (d.x1 + d.x2) / 2, iy = d.y2; // feet
        // with a moving camera, f.G maps this frame onto the reference frame the floor corners were set on
        const [rx, ry] = f.G ? applyH(f.G, ix, iy) : [ix, iy];
        const [x, y] = applyH(H, rx, ry);
        return { x, y, ix, iy, score: d.score, h: d.y2 - d.y1, kp: d.kp || null };
      }).filter(p => p.x > -margin && p.x < 1 + margin && p.y > -margin && p.y < 1 + margin)
    }));
  }
  function autoCount(sp) {
    const counts = sp.map(f => f.pts.length).filter(c => c > 0);
    if (!counts.length) return 0;
    const hist = {};
    counts.forEach(c => hist[c] = (hist[c] || 0) + 1);
    let best = 0, bc = -1;
    for (const k in hist) if (hist[k] > bc || (hist[k] === bc && +k > best)) { bc = hist[k]; best = +k; }
    return best;
  }

  // multi-target tracking on the stage plane, fixed number of identities
  function track(sp, N, opts) {
    opts = Object.assign({ gate: 0.08, maxSpeed: 1.6, regate: 0.45, lostAfter: 1.2, alpha: 0.8, vmax: 1.2, reacquire: 0.4 }, opts || {});
    const clampV = v => Math.max(-opts.vmax, Math.min(opts.vmax, v));
    const clampP = v => Math.max(-0.05, Math.min(1.05, v));
    const T = sp.length;
    const tracks = [];
    if (!T || N < 1) return { times: [], tracks };
    // initial frame: first with >= N points, else the fullest
    let f0 = sp.findIndex(f => f.pts.length >= N);
    if (f0 < 0) { f0 = 0; sp.forEach((f, i) => { if (f.pts.length > sp[f0].pts.length) f0 = i; }); }
    const init = sp[f0].pts.slice().sort((a, b) => b.score - a.score).slice(0, N).sort((a, b) => a.x - b.x);
    for (let k = 0; k < N; k++) {
      const p = init[k] || { x: (k + 0.5) / N, y: 0.5, ix: null, iy: null };
      tracks.push({ x: p.x, y: p.y, vx: 0, vy: 0, last: init[k] ? sp[f0].t : -1e9, born: !!init[k], pts: new Array(T) });
    }
    const step = (i) => {
      const f = sp[i];
      const dt = i > 0 ? Math.max(1e-3, Math.abs(f.t - sp[i - 1].t)) : 0;
      const pred = tracks.map(tr => ({ x: tr.x + tr.vx * dt, y: tr.y + tr.vy * dt }));
      const cost = tracks.map((tr, k) => f.pts.map(p => {
        const d = Math.hypot(p.x - pred[k].x, p.y - pred[k].y);
        const lost = (f.t - tr.last) > opts.lostAfter || !tr.born;
        const g = lost ? opts.regate : opts.gate + opts.maxSpeed * Math.max(dt, Math.abs(f.t - tr.last)) * 0.6;
        return d <= g ? d + (lost ? 0.2 : 0) : 1e5;
      }));
      const asg = f.pts.length ? hungarian(cost) : tracks.map(() => -1);
      for (let k = 0; k < asg.length; k++) if (asg[k] >= 0 && cost[k][asg[k]] >= 1e5) asg[k] = -1;
      // second pass: a track missing for a while takes over any detection nobody claimed, however far,
      // so a dancer who reappears after being hidden is picked up again instead of being left behind
      const freeDet = f.pts.map((_, j) => j).filter(j => !asg.includes(j));
      const lostTr = tracks.map((_, k) => k).filter(k => asg[k] < 0 && (!tracks[k].born || f.t - tracks[k].last > opts.reacquire || tracks[k].last - f.t > opts.reacquire));
      if (freeDet.length && lostTr.length) {
        const c2 = lostTr.map(k => freeDet.map(j => Math.hypot(f.pts[j].x - pred[k].x, f.pts[j].y - pred[k].y)));
        const a2 = hungarian(c2);
        lostTr.forEach((k, r) => { if (a2[r] >= 0) { asg[k] = freeDet[a2[r]]; cost[k][asg[k]] = 0; tracks[k].vx = tracks[k].vy = 0; tracks[k].reset = true; } });
      }
      tracks.forEach((tr, k) => {
        const j = asg[k];
        if (j >= 0 && cost[k][j] < 1e5) {
          const p = f.pts[j];
          const a = tr.reset ? 1 : opts.alpha;
          const nx = a * p.x + (1 - a) * pred[k].x, ny = a * p.y + (1 - a) * pred[k].y;
          if (dt > 0 && tr.born && !tr.reset) { tr.vx = clampV(0.3 * tr.vx + 0.7 * (nx - tr.x) / dt); tr.vy = clampV(0.3 * tr.vy + 0.7 * (ny - tr.y) / dt); }
          tr.reset = false;
          tr.x = nx; tr.y = ny; tr.last = f.t; tr.born = true;
          tr.pts[i] = { x: tr.x, y: tr.y, ok: true, ix: p.ix, iy: p.iy, kp: p.kp, h: p.h };
        } else {
          tr.vx *= 0.3; tr.vy *= 0.3;
          tr.x = clampP(pred[k].x); tr.y = clampP(pred[k].y);
          const alive = tr.born && (f.t - tr.last) <= opts.lostAfter;
          tr.pts[i] = { x: tr.x, y: tr.y, ok: false, alive, ix: null, iy: null };
        }
      });
    };
    // run backward from f0 to 0 then forward from f0
    for (let i = f0; i >= 0; i--) step(i);
    tracks.forEach(tr => { tr.x = tr.pts[f0].x; tr.y = tr.pts[f0].y; tr.vx = tr.vy = 0; tr.last = sp[f0].t; });
    for (let i = f0; i < T; i++) step(i);
    // light smoothing (centered 3-tap) on matched points
    const out = tracks.map(tr => {
      const P = tr.pts;
      return P.map((p, i) => {
        const a = P[i - 1] || p, b = P[i + 1] || p;
        const q = { x: (a.x + 2 * p.x + b.x) / 4, y: (a.y + 2 * p.y + b.y) / 4, on: p.ok || p.alive !== false, ok: p.ok, ix: p.ix, iy: p.iy };
        if (p.kp) { q.kp = p.kp; q.h = p.h; }
        return q;
      });
    });
    return { times: sp.map(f => f.t), tracks: out };
  }

  // position of each track at time t (linear interpolation)
  function posAt(td, t) {
    const T = td.times;
    if (!T.length) return [];
    let lo = 0, hi = T.length - 1;
    if (t <= T[0]) hi = lo = 0; else if (t >= T[hi]) lo = hi;
    else { while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (T[mid] <= t) lo = mid; else hi = mid; } }
    const u = hi === lo ? 0 : (t - T[lo]) / (T[hi] - T[lo]);
    return td.tracks.map(P => {
      const a = P[lo], b = P[hi];
      return { x: a.x + (b.x - a.x) * u, y: a.y + (b.y - a.y) * u, on: u < 0.5 ? a.on : b.on };
    });
  }

  // ---------- synthetic demo choreography (8 dancers) ----------
  function demoChoreo() {
    const N = 8;
    const F = {
      split: [[0.2, 0.42], [0.3, 0.3], [0.38, 0.5], [0.27, 0.62], [0.62, 0.48], [0.72, 0.36], [0.82, 0.5], [0.72, 0.64]],
      vee: [[0.14, 0.3], [0.86, 0.3], [0.24, 0.45], [0.76, 0.45], [0.34, 0.6], [0.66, 0.6], [0.44, 0.76], [0.56, 0.76]],
      line: [[0.1, 0.62], [0.214, 0.62], [0.329, 0.62], [0.443, 0.62], [0.557, 0.62], [0.671, 0.62], [0.786, 0.62], [0.9, 0.62]],
      block: [[0.38, 0.42], [0.46, 0.42], [0.54, 0.42], [0.62, 0.42], [0.38, 0.55], [0.46, 0.55], [0.54, 0.55], [0.62, 0.55]],
      center: [[0.3, 0.35], [0.7, 0.35], [0.22, 0.52], [0.78, 0.52], [0.36, 0.66], [0.64, 0.66], [0.5, 0.45], [0.5, 0.82]]
    };
    const circle = (rot) => Array.from({ length: N }, (_, k) => {
      const a = rot + k / N * Math.PI * 2;
      return [0.5 + 0.28 * Math.cos(a), 0.5 + 0.22 * Math.sin(a)];
    });
    const bpm = 120, spb = 60 / bpm;
    // reorder a formation so each dancer walks to the nearest free spot (as a choreographer would)
    const fit = (prev, next) => {
      const asg = hungarian(prev.map(p => next.map(q => Math.hypot(p[0] - q[0], p[1] - q[1]))));
      return asg.map(j => next[j]);
    };
    // keyframes [beat, positions, ease]; consecutive frames with the same positions are holds
    const K = [];
    let cur = F.split;
    const hold = (b0, b1) => { K.push([b0, cur]); K.push([b1, cur]); };
    const go = (form) => { cur = fit(cur, form); };
    hold(0, 6); go(F.vee); hold(8, 14); go(F.line); hold(16, 20);
    // pairs trade places along the line (a deliberate crossing)
    const L0 = cur, Ls = L0.map((p, k) => L0.findIndex(q => q === F.line[(F.line.indexOf(p) ^ 1)]));
    for (let i = 1; i <= 8; i++) {
      const e = 0.5 - 0.5 * Math.cos(Math.PI * i / 8);
      K.push([20 + i / 2, L0.map((p, k) => { const q = L0[Ls[k]]; return [p[0] + (q[0] - p[0]) * e, p[1] + (k < Ls[k] ? 0.1 : -0.1) * Math.sin(Math.PI * e)]; }), 'lin']);
    }
    cur = L0.map((p, k) => L0[Ls[k]]); hold(24, 26);
    go(F.block); hold(28, 32);
    // block opens into a circle that turns three quarters
    let rot = 0; go(circle(0)); K.push([34, cur]);
    rot = Math.atan2(cur[0][1] - 0.5, cur[0][0] - 0.5);
    const order = cur.map(p => Math.atan2(p[1] - 0.5, p[0] - 0.5));
    for (let i = 1; i <= 16; i++) { const r = i / 16 * Math.PI * 1.5; K.push([34 + i / 2, order.map(a => [0.5 + 0.28 * Math.cos(a + r), 0.5 + 0.22 * Math.sin(a + r)]), 'lin']); }
    cur = K[K.length - 1][1];
    go(F.center); hold(44, 52); go(F.split); hold(54, 64);
    const dur = 64 * spb, fps = 10, times = [], tracks = Array.from({ length: N }, () => []);
    const ease = u => u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2;
    function at(beat) {
      let i = 0; while (i < K.length - 2 && K[i + 1][0] <= beat) i++;
      const a = K[i], b = K[i + 1];
      let u = b[0] === a[0] ? 0 : Math.min(1, Math.max(0, (beat - a[0]) / (b[0] - a[0])));
      if (b[2] !== 'lin') u = ease(u);
      return a[1].map((p, k) => [p[0] + (b[1][k][0] - p[0]) * u, p[1] + (b[1][k][1] - p[1]) * u]);
    }
    let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647 - 0.5);
    for (let i = 0; i <= dur * fps; i++) {
      const t = i / fps; times.push(t);
      const P = at(t / spb);
      P.forEach((p, k) => tracks[k].push({ x: p[0] + rnd() * 0.006, y: p[1] + rnd() * 0.006, on: true, ok: true, ix: null, iy: null }));
    }
    return { td: { times, tracks }, bpm, offset: 0, duration: dur };
  }

  // ---------- music ----------
  const SCALES = {
    major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10],
    dorian: [0, 2, 3, 5, 7, 9, 10], penta: [0, 2, 4, 7, 9]
  };
  const PARENT_SHIFT = { major: 0, minor: 3, dorian: -2, penta: 0 };
  const FIFTHS = { 0: 0, 7: 1, 2: 2, 9: 3, 4: 4, 11: 5, 6: 6, 5: -1, 10: -2, 3: -3, 8: -4, 1: -5 };
  function keyFifths(root, mode) { return FIFTHS[((root + PARENT_SHIFT[mode]) % 12 + 12) % 12]; }
  function degPitch(scale, root, base, idx) {
    const L = scale.length, o = Math.floor(idx / L), d = ((idx % L) + L) % L;
    return base + root + 12 * o + scale[d];
  }

  // ---------- mapping (movement feature -> musical parameter) ----------
  const SPEED_FULL = 0.6;            // stage widths per second that counts as full speed
  const DENSITY_ON = 0.1;            // = 0.06 stage widths/s, the original "moving" threshold
  const MAP_SOURCES = ['x', 'y', 'speed', 'center', 'fixed'];
  const DEFAULT_MAP = {
    pitch: { src: 'x', inv: false },
    dynamics: { src: 'y', inv: false },
    density: { src: 'speed', inv: false, fastest: 'quarter' },
    maxHold: 16                      // eighths; a note is re-struck after two bars at most
  };
  function normMap(m) {
    m = m || {};
    const pick = (k) => {
      const d = DEFAULT_MAP[k], v = m[k] || {};
      return { src: MAP_SOURCES.includes(v.src) ? v.src : d.src, inv: !!v.inv, fastest: v.fastest === 'eighth' ? 'eighth' : (d.fastest || 'quarter') };
    };
    const mh = [4, 8, 16, 32].includes(+m.maxHold) ? +m.maxHold : DEFAULT_MAP.maxHold;
    return { pitch: pick('pitch'), dynamics: pick('dynamics'), density: pick('density'), maxHold: mh };
  }

  // Compose the two layers on an eighth-note grid.
  // settings: {bpm, offset, duration, root, mode, melodySpan(octaves)}
  function compose(td, s) {
    const scale = SCALES[s.mode] || SCALES.major, L = scale.length;
    const stepDur = 60 / s.bpm / 2;
    const nSteps = Math.max(8, Math.ceil((s.duration - s.offset) / stepDur / 8) * 8);
    const N = td.tracks.length;
    const span = (s.melodySpan || 2) * L; // number of scale steps across the stage width
    const grid = [];
    for (let k = 0; k < nSteps; k++) grid.push(posAt(td, s.offset + k * stepDur));

    // Layer 1: one melodic voice per dancer. Which movement drives which parameter comes from s.map;
    // the defaults reproduce the original rules exactly.
    const M = normMap(s.map);
    const melodies = [];
    for (let d = 0; d < N; d++) {
      const notes = []; let cur = null, idxF = null;
      for (let k = 0; k < nSteps; k++) {
        const p = grid[k][d];
        const prev = k ? grid[k - 1][d] : p;
        const speed = Math.hypot(p.x - prev.x, p.y - prev.y) / stepDur; // stage widths / s
        if (!p.on) { if (cur) { notes.push(cur); cur = null; } idxF = null; continue; }
        const src = { x: Math.min(1, Math.max(0, p.x)), y: Math.min(1, Math.max(0, p.y)), speed: Math.min(1, speed / SPEED_FULL),
          center: Math.min(1, Math.hypot(p.x - 0.5, p.y - 0.5) / 0.7071), fixed: 0.5 };
        const val = (m) => { const v = src[m.src]; return m.inv ? 1 - v : v; };
        const xf = val(M.pitch) * span;
        // hysteresis: keep the current degree until the value moves 0.3 of a step past its edge
        let idx = idxF;
        if (idx == null || Math.abs(xf - (idx + 0.5)) > 0.8) idx = Math.min(span - 1, Math.floor(xf));
        const vel = Math.round(38 + val(M.dynamics) * 82);
        // note density: below the threshold notes are held; above it they re-strike on every beat,
        // or on every eighth when "fastest" is eighth and the value is in the upper half
        const dv = val(M.density);
        const active = dv > DENSITY_ON;
        const every = M.density.fastest === 'eighth' && dv >= 0.5 ? 1 : 2;
        const onGrid = k % every === 0;
        const newPitch = idx !== idxF;
        const reStrike = active && onGrid && cur && (k - cur.start) >= every;
        const tooLong = cur && (k - cur.start) >= M.maxHold;
        if (!cur || newPitch || reStrike || tooLong) {
          if (cur) notes.push(cur);
          cur = { start: k, dur: 1, midi: degPitch(scale, s.root, 60, idx), vel };
        } else cur.dur++;
        idxF = idx;
      }
      if (cur) notes.push(cur);
      melodies.push(notes);
    }

    // Layer 2: one chord per beat from the whole formation
    const chords = []; let last = null;
    const feats = [];
    for (let k = 0; k < nSteps; k += 2) {
      const P = grid[k].filter(p => p.on);
      if (P.length < 2) { if (last) { chords.push(last); last = null; } feats.push(null); continue; }
      const f = formationFeatures(P);
      feats.push(f);
      const rootDeg = Math.round((Math.min(1, Math.max(0, f.cx)) - 0.5) * L * 1.2); // centre stage = tonic
      let degs, kind;
      if (f.lineness > 0.88) { degs = [0, 3, 6]; kind = 'line'; }            // quartal stack
      else if (f.symmetry >= 0.62) { degs = [0, 2, 4]; kind = 'sym'; }       // triad
      else if (f.symmetry >= 0.35) { degs = [0, 2, 4, 6]; kind = 'semi'; }   // seventh
      else { degs = [0, 1, 2, 4]; kind = 'asym'; }                            // cluster
      const open = f.spread > 0.24;
      const base = open ? 36 : 48;
      let notes = degs.map((g, i) => degPitch(scale, s.root, base, rootDeg + g) + (open && i % 2 === 1 ? 12 : 0));
      notes = Array.from(new Set(notes)).sort((a, b) => a - b);
      const vel = Math.round(46 + Math.min(1, f.cy) * 40);
      const key = notes.join(',');
      if (last && last.key === key) last.dur += 2;
      else { if (last) chords.push(last); last = { start: k, dur: 2, notes, vel, key, kind }; }
    }
    if (last) chords.push(last);
    return { melodies, chords, nSteps, stepDur, feats, settings: s };
  }

  function formationFeatures(P) {
    const n = P.length;
    const cx = P.reduce((a, p) => a + p.x, 0) / n, cy = P.reduce((a, p) => a + p.y, 0) / n;
    let sxx = 0, syy = 0, sxy = 0;
    P.forEach(p => { const dx = p.x - cx, dy = p.y - cy; sxx += dx * dx; syy += dy * dy; sxy += dx * dy; });
    sxx /= n; syy /= n; sxy /= n;
    const tr = sxx + syy, det = sxx * syy - sxy * sxy, disc = Math.sqrt(Math.max(0, tr * tr / 4 - det));
    const l1 = tr / 2 + disc, l2 = tr / 2 - disc;
    const lineness = l1 > 1e-6 ? 1 - l2 / l1 : 0;
    const spread = Math.sqrt(tr);
    // mirror symmetry about the vertical axis through the centroid
    let dsum = 0;
    P.forEach(p => {
      const mx = 2 * cx - p.x;
      let best = Infinity;
      P.forEach(q => { const d = Math.hypot(q.x - mx, q.y - p.y); if (d < best) best = d; });
      dsum += best;
    });
    const symmetry = Math.max(0, 1 - (dsum / n) / Math.max(0.04, spread * 0.6));
    return { cx, cy, spread, lineness, symmetry };
  }

  // ---------- MusicXML ----------
  const SHARP = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'], SH_ALT = [0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0];
  const FLAT = ['C', 'D', 'D', 'E', 'E', 'F', 'G', 'G', 'A', 'A', 'B', 'B'], FL_ALT = [0, -1, 0, -1, 0, 0, -1, 0, -1, 0, -1, 0];
  function pitchXML(m, flats) {
    const pc = m % 12, oct = Math.floor(m / 12) - 1;
    const step = flats ? FLAT[pc] : SHARP[pc], alt = flats ? FL_ALT[pc] : SH_ALT[pc];
    return `<pitch><step>${step}</step>${alt ? `<alter>${alt}</alter>` : ''}<octave>${oct}</octave></pitch>`;
  }
  const TYPES = { 1: ['eighth', 0], 2: ['quarter', 0], 3: ['quarter', 1], 4: ['half', 0], 6: ['half', 1], 8: ['whole', 0] };
  function splitDur(d) { // into notatable pieces (eighth units)
    const out = []; const opts = [8, 6, 4, 3, 2, 1];
    while (d > 0) { const p = opts.find(o => o <= d); out.push(p); d -= p; }
    return out;
  }
  // events: [{start, dur, notes:[midi]}] (non-overlapping) -> measures of XML
  function voiceMeasures(events, nSteps, flats) {
    const nMeas = nSteps / 8, meas = Array.from({ length: nMeas }, () => []);
    let t = 0;
    const put = (start, dur, notes) => {
      // split at barlines, then into notatable values; tie the pieces of one sounding note
      const pieces = []; let s = start, rem = dur;
      while (rem > 0) {
        const mi = Math.floor(s / 8), inBar = Math.min(rem, 8 - (s % 8));
        // keep beat alignment: an off-beat start gets an eighth first
        let left = inBar, pos = s % 8;
        while (left > 0) {
          let p = splitDur(left)[0];
          if (pos % 2 === 1) p = 1;
          else if (p >= 4 && pos % 4 !== 0) p = 2;
          pieces.push({ mi, dur: p }); left -= p; pos += p;
        }
        s += inBar; rem -= inBar;
      }
      pieces.forEach((pc, i) => meas[pc.mi] && meas[pc.mi].push({
        dur: pc.dur, notes, tieStart: !!notes && i < pieces.length - 1, tieStop: !!notes && i > 0
      }));
    };
    events.forEach(e => {
      if (e.start > t) put(t, e.start - t, null);
      const d = Math.min(e.dur, nSteps - e.start);
      if (d > 0) put(e.start, d, e.notes);
      t = e.start + d;
    });
    if (t < nSteps) put(t, nSteps - t, null);
    return meas.map(items => items.map(it => {
      const [type, dot] = TYPES[it.dur];
      const tail = `<duration>${it.dur}</duration>` +
        (it.tieStop ? '<tie type="stop"/>' : '') + (it.tieStart ? '<tie type="start"/>' : '') +
        `<type>${type}</type>${dot ? '<dot/>' : ''}`;
      const nots = (it.tieStop || it.tieStart) ? `<notations>${it.tieStop ? '<tied type="stop"/>' : ''}${it.tieStart ? '<tied type="start"/>' : ''}</notations>` : '';
      if (!it.notes) return `<note><rest/>${tail}</note>`;
      return it.notes.map((m, i) => `<note>${i ? '<chord/>' : ''}${pitchXML(m, flats)}${tail}${nots}</note>`).join('');
    }).join(''));
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

  // parts: [{name, program, clef:'G'|'F', events:[{start,dur,notes}]}]
  function toMusicXML(parts, nSteps, bpm, fifths, title) {
    const flats = fifths < 0;
    let x = `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">\n<score-partwise version="4.0"><work><work-title>${esc(title)}</work-title></work><part-list>`;
    parts.forEach((p, i) => {
      x += `<score-part id="P${i + 1}"><part-name>${esc(p.name)}</part-name><score-instrument id="P${i + 1}-I1"><instrument-name>${esc(p.instrument || p.name)}</instrument-name></score-instrument><midi-instrument id="P${i + 1}-I1"><midi-channel>${(i % 15) + 1 + (i >= 9 ? 1 : 0)}</midi-channel><midi-program>${(p.program || 0) + 1}</midi-program></midi-instrument></score-part>`;
    });
    x += '</part-list>';
    parts.forEach((p, i) => {
      const ms = voiceMeasures(p.events, nSteps, flats);
      x += `<part id="P${i + 1}">`;
      ms.forEach((body, mi) => {
        let attr = '';
        if (mi === 0) {
          attr = `<attributes><divisions>2</divisions><key><fifths>${fifths}</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time><clef><sign>${p.clef}</sign><line>${p.clef === 'F' ? 4 : 2}</line></clef></attributes>`;
          if (i === 0) attr += `<direction placement="above"><direction-type><metronome><beat-unit>quarter</beat-unit><per-minute>${Math.round(bpm)}</per-minute></metronome></direction-type><sound tempo="${Math.round(bpm)}"/></direction>`;
        }
        x += `<measure number="${mi + 1}">${attr}${body}</measure>`;
      });
      x += '</part>';
    });
    return x + '</score-partwise>';
  }

  // ---------- Standard MIDI file ----------
  function vlq(n) { const b = [n & 0x7f]; while ((n >>= 7)) b.unshift((n & 0x7f) | 0x80); return b; }
  function toMIDI(parts, bpm) {
    const PPQ = 480, E = PPQ / 2;
    const str = s => Array.from(new TextEncoder().encode(s));
    const tracks = [];
    const tempo = Math.round(60000000 / bpm);
    tracks.push([0, 0xff, 0x51, 3, (tempo >> 16) & 255, (tempo >> 8) & 255, tempo & 255, 0, 0xff, 0x58, 4, 4, 2, 24, 8, 0, 0xff, 0x2f, 0]);
    parts.forEach((p, i) => {
      let ch = i < 9 ? i : i + 1; if (ch > 15) ch = 15;
      const ev = [];
      p.events.forEach(e => e.notes.forEach(m => {
        ev.push({ t: Math.max(0, Math.round(e.start * E)), on: 1, m, v: e.vel || 80 });
        ev.push({ t: Math.max(1, Math.round((e.start + e.dur) * E) - 1), on: 0, m, v: 0 });
      }));
      ev.sort((a, b) => a.t - b.t || a.on - b.on);
      const name = str(p.name);
      const data = [0, 0xff, 0x03, ...vlq(name.length), ...name, 0, 0xc0 | ch, p.program || 0];
      let t = 0;
      ev.forEach(e => { data.push(...vlq(e.t - t), (e.on ? 0x90 : 0x80) | ch, e.m, e.v); t = e.t; });
      data.push(0, 0xff, 0x2f, 0);
      tracks.push(data);
    });
    const bytes = [...str('MThd'), 0, 0, 0, 6, 0, 1, (tracks.length >> 8) & 255, tracks.length & 255, (PPQ >> 8) & 255, PPQ & 255];
    tracks.forEach(d => { const L = d.length; bytes.push(...str('MTrk'), (L >>> 24) & 255, (L >> 16) & 255, (L >> 8) & 255, L & 255, ...d); });
    return new Uint8Array(bytes);
  }

  function tracksCSV(td, names) {
    let s = 'time_s,' + names.map(n => `${n}_x,${n}_y,${n}_onstage`).join(',') + '\n';
    td.times.forEach((t, i) => {
      s += t.toFixed(3) + ',' + td.tracks.map(P => `${P[i].x.toFixed(4)},${P[i].y.toFixed(4)},${P[i].on ? 1 : 0}`).join(',') + '\n';
    });
    return s;
  }

  G.Core = { homography, applyH, invertH, UNIT, decodeYolo, decodePose, nms, hungarian, stagePoints, autoCount, track, posAt,
    demoChoreo, SCALES, DEFAULT_MAP, normMap, keyFifths, compose, formationFeatures, toMusicXML, toMIDI, tracksCSV, splitDur };
})(typeof window !== 'undefined' ? window : globalThis);
