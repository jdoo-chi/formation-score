/* Formation Score — Ensemble arrangement (strings & piano).
   Reads body poses as well as floor positions:
   - each dancer's sharp limb accents ("hits") become notes on the song's eighth-note grid
   - the dancer at centre stage plays the lead line; raised arms push it higher
   - every new formation moves the harmony to the next chord of a progression
   - hits made together by most of the group land as low piano octaves, contrabass and timpani
   - a formation change is bridged by a harp run into the new chord
   Pure functions, no DOM. Needs tracks from Core.track() whose points carry pose keypoints (kp) and box height (h). */
(function (G) {
  'use strict';
  const C = G.Core;

  const KEY_SCALES = { major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10], dorian: [0, 2, 3, 5, 7, 9, 10] };
  const PROGRESSIONS = { major: [0, 4, 5, 3], minor: [0, 5, 2, 6], dorian: [0, 3, 6, 0] };   // I-V-vi-IV, i-VI-III-VII, i-IV-VII-i
  const ROMAN_MAJ = ['I', 'ii', 'iii', 'IV', 'V', 'vi', 'vii°'];
  const NOTE = ['C', 'C♯', 'D', 'E♭', 'E', 'F', 'F♯', 'G', 'A♭', 'A', 'B♭', 'B'];
  const DANCER_INST = ['violin', 'piano', 'viola', 'harp', 'cello', 'pizzicato', 'piano', 'violin', 'viola', 'harp', 'cello', 'piano'];
  const GM = { piano: 0, violin: 40, viola: 41, cello: 42, contrabass: 43, pizzicato: 45, harp: 46, timpani: 47, strings: 48 };
  const INST_NAME = { piano: 'Piano', violin: 'Violin', viola: 'Viola', cello: 'Cello', contrabass: 'Contrabass', pizzicato: 'Pizzicato strings', harp: 'Harp', timpani: 'Timpani', strings: 'Strings' };
  const LIMBS = [9, 10, 7, 8, 15, 16, 13, 14];   // wrists, elbows, ankles, knees (COCO order)

  function hasPoses(td) {
    if (!td || !td.tracks.length) return false;
    let n = 0, tot = 0;
    td.tracks.forEach(P => P.forEach(p => { tot++; if (p.kp) n++; }));
    return tot > 0 && n / tot > 0.3;
  }

  // fill gaps by linear interpolation; returns a new array
  function fill(a) {
    const out = a.slice(), idx = [];
    a.forEach((v, i) => { if (v != null && isFinite(v)) idx.push(i); });
    if (!idx.length) return out.map(() => 0);
    for (let i = 0; i < out.length; i++) {
      if (out[i] != null && isFinite(out[i])) continue;
      let j = idx.findIndex(x => x > i);
      if (j <= 0) { out[i] = a[idx[j < 0 ? idx.length - 1 : 0]]; continue; }
      const i0 = idx[j - 1], i1 = idx[j], u = (i - i0) / (i1 - i0);
      out[i] = a[i0] + (a[i1] - a[i0]) * u;
    }
    return out;
  }
  const median = a => { const s = a.slice().sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : 0; };
  const pct = (a, p) => { const s = a.slice().sort((x, y) => x - y); return s.length ? s[Math.min(s.length - 1, Math.floor(s.length * p))] : 0; };

  // ---------- body signals per dancer ----------
  function bodySignals(td) {
    const T = td.times, n = T.length;
    return td.tracks.map(P => {
      const h = fill(P.map(p => (p.kp && p.h > 0) ? p.h : null)).map(v => Math.max(v || 40, 40));
      const xy = [];
      for (let j = 0; j < 17; j++) {
        const ok = i => P[i].kp && P[i].kp[j][2] > 0.3;
        xy.push([fill(P.map((p, i) => ok(i) ? p.kp[j][0] : null)), fill(P.map((p, i) => ok(i) ? p.kp[j][1] : null))]);
      }
      const hipx = xy[11][0].map((v, i) => (v + xy[12][0][i]) / 2), hipy = xy[11][1].map((v, i) => (v + xy[12][1][i]) / 2);
      const rel = (j, i) => [(xy[j][0][i] - hipx[i]) / h[i], (xy[j][1][i] - hipy[i]) / h[i]];
      const energy = new Array(n).fill(0), acc = new Array(n).fill(0), arm = new Array(n).fill(0);
      const vprev = LIMBS.map(() => [0, 0]);
      for (let i = 0; i < n; i++) {
        const dt = i ? Math.max(0.02, T[i] - T[i - 1]) : 0.125;
        let sp = 0, ac = 0;
        LIMBS.forEach((j, q) => {
          const a = rel(j, i), b = i ? rel(j, i - 1) : a;
          const v = [(a[0] - b[0]) / dt, (a[1] - b[1]) / dt];
          sp += Math.hypot(v[0], v[1]);
          ac += Math.hypot(v[0] - vprev[q][0], v[1] - vprev[q][1]) / dt;
          vprev[q] = v;
        });
        energy[i] = sp / LIMBS.length; acc[i] = i > 1 ? ac / LIMBS.length : 0;
        arm[i] = -(rel(9, i)[1] + rel(10, i)[1]) / 2;   // wrists above the hips -> positive
      }
      // light 3-tap smoothing
      const sm = a => a.map((v, i) => ((a[i - 1] ?? v) + 2 * v + (a[i + 1] ?? v)) / 4);
      return { energy: sm(energy), acc: sm(acc), arm: sm(arm) };
    });
  }

  // ---------- the arrangement ----------
  // s: {bpm, offset, root, mode, duration}
  function arrange(td, s) {
    const T = td.times, N = td.tracks.length;
    const step = 60 / s.bpm / 2;                                // eighth note
    const scale = KEY_SCALES[s.mode] || KEY_SCALES.major;
    const prog = PROGRESSIONS[s.mode] || PROGRESSIONS.major;
    const ton = 48 + s.root;                                     // tonic in octave 3
    const degPitch = (d, base) => { const o = Math.floor(d / 7), r = ((d % 7) + 7) % 7; return (base ?? ton) + 12 * o + scale[r]; };
    const slotT = k => s.offset + k * step;
    const slotOf = t => Math.round((t - s.offset) / step);
    const S_A = Math.max(0, Math.ceil((T[0] - s.offset) / step)), S_B = Math.floor((Math.min(s.duration, T[T.length - 1]) - s.offset) / step);
    const nSteps = Math.max(8, Math.ceil((S_B + 1) / 8) * 8);
    const sig = bodySignals(td);
    const at = (arr, t) => {
      if (t <= T[0]) return arr[0]; if (t >= T[T.length - 1]) return arr[arr.length - 1];
      let lo = 0, hi = T.length - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (T[m] <= t) lo = m; else hi = m; }
      const u = (t - T[lo]) / (T[hi] - T[lo]); return arr[lo] + (arr[hi] - arr[lo]) * u;
    };

    // hits: peaks in limb acceleration above median + 1.6 MAD, at least 0.16 s apart, snapped to eighths
    const hitsBySlot = new Map(); let hitCount = 0;
    sig.forEach((g, k) => {
      const a = g.acc, med = median(a), mad = median(a.map(v => Math.abs(v - med))) + 1e-6, thr = med + 1.6 * mad;
      let last = -1e9;
      for (let i = 1; i < a.length - 1; i++) {
        if (!td.tracks[k][i].on) continue;
        if (a[i] >= thr && a[i] >= a[i - 1] && a[i] > a[i + 1] && T[i] - last >= 0.16) {
          last = T[i];
          const sl = slotOf(T[i]); if (sl < S_A || sl > S_B) continue;
          const strength = Math.min(1, (a[i] - med) / (6 * mad));
          const L = hitsBySlot.get(sl) || []; const ex = L.find(h => h.k === k);
          if (ex) ex.g = Math.max(ex.g, strength); else { L.push({ k, g: strength }); hitCount++; }
          hitsBySlot.set(sl, L);
        }
      }
    });
    const hitsAt = sl => hitsBySlot.get(sl) || [];

    // formation changes: group floor speed above its 70th percentile for at least 0.35 s
    const gspeed = T.map((t, i) => {
      let sum = 0, c = 0;
      td.tracks.forEach(P => { const a = P[i], b = P[Math.min(P.length - 1, i + 2)]; const dt = (T[Math.min(T.length - 1, i + 2)] - t) || 1; if (a.on && b.on) { sum += Math.hypot(b.x - a.x, b.y - a.y) / dt; c++; } });
      return c ? sum / c : 0;
    });
    const gs = gspeed.map((v, i) => { let a = 0, c = 0; for (let j = i - 2; j <= i + 2; j++) if (gspeed[j] != null) { a += gspeed[j]; c++; } return a / c; });
    const thrG = Math.max(0.05, pct(gs, 0.7));
    const transitions = []; let cur = null;
    gs.forEach((v, i) => {
      if (v > thrG) { if (!cur) cur = [T[i], T[i]]; else cur[1] = T[i]; }
      else if (cur) { if (cur[1] - cur[0] >= 0.35) transitions.push(cur); cur = null; }
    });
    if (cur && cur[1] - cur[0] >= 0.35) transitions.push(cur);

    // chords: one per formation; a formation held longer than four bars moves on by itself
    const bar = step * 8, tA = slotT(S_A), tB = slotT(S_B);
    const changes = [tA];
    transitions.map(x => x[1]).filter(t => t > tA + step * 2 && t < tB).concat([tB]).forEach(t => {
      while (t - changes[changes.length - 1] > 4 * bar) changes.push(changes[changes.length - 1] + 2 * bar);
      if (t < tB && t - changes[changes.length - 1] > step * 2) changes.push(t);
    });
    const chords = changes.map((t, i) => {
      const sA = slotOf(t), sB = i + 1 < changes.length ? slotOf(changes[i + 1]) : S_B + 1;
      const P = C.posAt(td, Math.min(t + step * 2, T[T.length - 1])).filter(p => p.on);
      const f = P.length > 1 ? C.formationFeatures(P) : { symmetry: 1, spread: 0.2, lineness: 0 };
      const root = prog[i % prog.length];
      let color, add;
      if (f.lineness > 0.93) { color = 'sus2'; add = [0, 1, 4]; }
      else if (f.symmetry >= 0.6) { color = ''; add = [0, 2, 4]; }
      else if (f.symmetry >= 0.35) { color = '7'; add = [0, 2, 4, 6]; }
      else { color = 'add9'; add = [0, 2, 4, 8]; }
      const rootPc = (ton + scale[root]) % 12;
      const third = scale[(root + 2) % 7] - scale[root]; const minor = ((third % 12) + 12) % 12 === 3;
      const dim = ((scale[(root + 4) % 7] - scale[root] + 12) % 12) === 6;
      const name = NOTE[rootPc] + (dim ? 'dim' : minor ? 'm' : '') + color;
      return { s: sA, e: sB, root, tones: add.map(x => root + x), name, kind: color || 'triad', spread: f.spread, formation: i + 1 };
    }).filter(c => c.e > c.s);
    const chordAt = sl => chords.find(c => sl >= c.s && sl < c.e) || (sl < chords[0].s ? chords[0] : chords[chords.length - 1]);

    // the lead: dancer closest to centre stage (front-weighted), changes only after holding for two beats
    const center = []; let cc = null, hold = 0;
    T.forEach((t, i) => {
      const P = td.tracks.map(Q => Q[i]);
      let best = 0, bs = -1e9;
      P.forEach((p, k) => { const sc = p.on ? -Math.abs(p.x - 0.5) * 2 + (p.y - 0.6) * 1.2 : -9; if (sc > bs) { bs = sc; best = k; } });
      const dt = i ? T[i] - T[i - 1] : 0;
      if (cc == null) cc = best;
      else if (best !== cc) { hold += dt; if (hold > step * 4) { cc = best; hold = 0; } }
      else hold = 0;
      center.push(cc);
    });
    const centerAt = t => { let lo = 0, hi = T.length - 1; if (t <= T[0]) return center[0]; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (T[m] <= t) lo = m; else hi = m; } return center[lo]; };

    const ev = [];   // {t, dur, midi, vel, inst, role, d, slot, slots}
    const add = (sl, slots, midi, vel, inst, role, d, t) => {
      const tt = t == null ? slotT(sl) : t;
      ev.push({ t: tt, dur: slots * step, midi: Math.round(midi), vel: Math.max(1, Math.min(127, Math.round(vel))), inst, role, d: d == null ? -1 : d, slot: sl, slots });
    };
    const instOf = k => DANCER_INST[k % DANCER_INST.length];

    // lead line
    const allArm = [].concat(...sig.map(g => g.arm)); const loA = pct(allArm, 0.1), hiA = pct(allArm, 0.95);
    let leadSlots = [];
    for (let sl = S_A; sl <= S_B; sl++) if (hitsAt(sl).some(h => h.k === centerAt(slotT(sl)))) leadSlots.push(sl);
    for (let sl = S_A; sl <= S_B; sl += 8) if (!leadSlots.some(x => Math.abs(x - sl) < 4)) leadSlots.push(sl);
    leadSlots = Array.from(new Set(leadSlots)).sort((a, b) => a - b);
    let prev = null;
    leadSlots.forEach((sl, i) => {
      const t = slotT(sl), k = centerAt(t), c = chordAt(sl);
      const a = (at(sig[k].arm, t) - loA) / Math.max(1e-6, hiA - loA);
      let deg = 7 + Math.round(Math.min(1.2, Math.max(0, a)) * 9);
      if (sl % 2 === 0) {
        let best = deg, bd = 99;
        c.tones.forEach(x => [0, 7, 14].forEach(o => { const y = x + o; if (Math.abs(y - deg) < bd) { bd = Math.abs(y - deg); best = y; } }));
        deg = best;
      }
      if (prev != null && Math.abs(deg - prev) > 5) deg = prev + Math.sign(deg - prev) * 4;
      prev = deg;
      const nxt = i + 1 < leadSlots.length ? leadSlots[i + 1] : sl + 4;
      const y = C.posAt(td, t)[k].y, g = (hitsAt(sl).find(h => h.k === k) || { g: 0.4 }).g;
      add(sl, Math.max(1, Math.min(6, nxt - sl)), degPitch(deg), 74 + 30 * g + 18 * (y - 0.6), instOf(k), 'lead', k);
    });

    // ensemble: everyone else plays a chord tone on each hit; stage left-to-right picks the tone
    for (let sl = S_A; sl <= S_B; sl++) {
      const L = hitsAt(sl); if (!L.length) continue;
      const c = chordAt(sl), t = slotT(sl), P = C.posAt(td, t), lead = centerAt(t);
      L.forEach(h => {
        if (h.k === lead) return;
        const x = Math.min(0.999, Math.max(0, P[h.k].x)), idx = Math.floor(x * c.tones.length * 2);
        const deg = c.tones[idx % c.tones.length] + 7 * Math.floor(idx / c.tones.length) + 2;
        add(sl, 1, degPitch(deg), 46 + 42 * h.g + 22 * (P[h.k].y - 0.6), instOf(h.k), 'ensemble', h.k);
      });
    }

    // strings pad and contrabass follow the chords
    chords.forEach(c => {
      let v = c.tones.map(d => degPitch(d));
      if (c.spread > 0.2) v = [v[0] - 12].concat(v.slice(1), [v[1] + 12]);
      v.forEach(m => add(c.s, c.e - c.s, m, 50, 'strings', 'strings'));
      add(c.s, c.e - c.s, degPitch(c.root, ton - 24), 82, 'contrabass', 'bass');
    });

    // hits made together: low piano octave + short contrabass; most of the group: timpani too
    for (let sl = S_A; sl <= S_B; sl++) {
      const n = hitsAt(sl).length; if (n < Math.max(3, Math.ceil(N * 0.55))) continue;
      const c = chordAt(sl), r = degPitch(c.root, ton - 12);
      add(sl, 2, r, 92, 'piano', 'accent'); add(sl, 2, r - 12, 88, 'piano', 'accent');
      if (n >= Math.ceil(N * 0.7)) add(sl, 3, degPitch(c.root, ton - 12) , 96, 'timpani', 'accent');
    }

    // formation changes: harp run up the new chord into the arrival
    const runs = [];
    transitions.forEach(([a, b]) => {
      if (b <= tA || b >= tB) return;
      const sEnd = slotOf(b), sBeg = Math.max(S_A, slotOf(Math.max(a, b - 1.2)));
      const c = chordAt(sEnd + 1), n = Math.max(4, (sEnd - sBeg) * 2);
      for (let j = 0; j < n; j++) {
        const t = slotT(sBeg) + (slotT(sEnd) - slotT(sBeg)) * j / n;
        const d = c.tones[j % c.tones.length] + 7 * (Math.floor(j / c.tones.length) % 3) + 7;
        add(null, 1.2, degPitch(d), 46 + 36 * j / n, 'harp', 'run', -1, t);
      }
      runs.push([a, b]);
    });

    ev.sort((x, y) => x.t - y.t);
    return { events: ev, chords, center, transitions: runs, hits: hitCount, step, nSteps, S_A, S_B, settings: s, leadChanges: center.filter((c, i) => i && c !== center[i - 1]).length };
  }

  // ---------- notation and MIDI parts ----------
  // monophonic per part: each note ends where the next one starts
  function mono(list) {
    const L = list.slice().sort((a, b) => a.slot - b.slot);
    return L.map((e, i) => ({ start: e.slot, dur: Math.max(1, Math.min(e.slots, (L[i + 1] ? L[i + 1].slot : e.slot + e.slots) - e.slot)), notes: [e.midi], vel: e.vel }))
      .filter((e, i, A) => !(i && A[i - 1].start === e.start));
  }
  function chordsBySlot(list) {
    const m = new Map();
    list.forEach(e => { const x = m.get(e.slot) || { start: e.slot, dur: e.slots, notes: [], vel: e.vel }; x.notes.push(e.midi); x.dur = Math.min(x.dur, e.slots); m.set(e.slot, x); });
    const L = Array.from(m.values()).sort((a, b) => a.start - b.start);
    L.forEach((e, i) => { if (L[i + 1]) e.dur = Math.max(1, Math.min(e.dur, L[i + 1].start - e.start)); e.notes = Array.from(new Set(e.notes)).sort((a, b) => a - b); });
    return L;
  }
  function scoreParts(A) {
    const E = A.events.filter(e => e.slot != null && e.slot >= 0);
    return [
      { name: 'Lead', instrument: 'Lead (centre dancer)', program: GM.violin, clef: 'G', events: mono(E.filter(e => e.role === 'lead')) },
      { name: 'Ensemble', instrument: 'Ensemble hits', program: GM.piano, clef: 'G', events: chordsBySlot(E.filter(e => e.role === 'ensemble')) },
      { name: 'Strings', instrument: 'Strings', program: GM.strings, clef: 'F', events: chordsBySlot(E.filter(e => e.role === 'strings')) },
      { name: 'Contrabass', instrument: 'Contrabass', program: GM.contrabass, clef: 'F', events: mono(E.filter(e => e.role === 'bass')) }
    ];
  }
  // MIDI: one track per instrument, times in eighth-note units (fractions allowed)
  function midiParts(A) {
    const by = new Map();
    A.events.forEach(e => {
      const p = by.get(e.inst) || { name: INST_NAME[e.inst], program: GM[e.inst], events: [] };
      p.events.push({ start: (e.t - A.settings.offset) / A.step, dur: e.dur / A.step, notes: [e.midi], vel: e.vel });
      by.set(e.inst, p);
    });
    return Array.from(by.values());
  }

  G.Arrange = { arrange, hasPoses, scoreParts, midiParts, DANCER_INST, INST_NAME, GM };
})(typeof window !== 'undefined' ? window : globalThis);
