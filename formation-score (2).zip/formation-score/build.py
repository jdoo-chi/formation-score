import sys, os
page = open('src/page.html', encoding='utf-8').read()
page = page.replace('/*__CSS__*/', open('src/style.css', encoding='utf-8').read()) \
           .replace('/*__CORE__*/', open('src/core.js', encoding='utf-8').read() + '\n' + open('src/arrange.js', encoding='utf-8').read()) \
           .replace('/*__APP__*/', open('src/app.js', encoding='utf-8').read())
# index.html: page content as published to Claude (the host adds the document head)
open('index.html', 'w', encoding='utf-8').write(page)
# dist/index.html: a complete standalone document for GitHub Pages or a local server
head = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n</head>\n<body>\n')
os.makedirs('dist', exist_ok=True)
open('dist/index.html', 'w', encoding='utf-8').write(head + page + '\n</body>\n</html>\n')
# local test copy that serves the CDN libraries from this folder
if len(sys.argv) > 1:
    t = page.replace('https://cdn.jsdelivr.net/npm/opensheetmusicdisplay@2.2.1/build/opensheetmusicdisplay.min.js', 'osmd.min.js') \
            .replace('https://cdn.jsdelivr.net/npm/onnxruntime-web@${ORT_VER}/dist/', sys.argv[1] + '/ortdist/') \
            .replace('https://cdn.jsdelivr.net/npm/@techstark/opencv-js@4.12.0-release.1/dist/opencv.js', sys.argv[1] + '/ortdist/opencv.js')
    open('test.html', 'w', encoding='utf-8').write(head + t + '\n</body>\n</html>\n')
print('ok', len(page))
