# Formation Score

Turn choreography footage into music. Upload a practice-room video or a full-stage fancam, and Formation Score tracks every dancer on the stage floor, maps their positions and the shape of the formation to music, plays it back in sync with the video, and exports MusicXML, MIDI and a CSV of stage coordinates.

Everything runs in the browser. Video never leaves the viewer's device.

## Workflow

1. **Upload** a video with a locked-off camera and the whole floor in view.
2. **Analyze**: drag four handles onto the floor corners, pick a sampling rate, run the person detector.
3. **Map**: choose which movement drives pitch, dynamics and note density; key, mode, stage width in octaves, tempo, first downbeat, a timbre per dancer.
4. **Compose**: listen with the voices and formation-chord layers on or off.
5. **Export**: MusicXML, MIDI and positions (as a .zip, or as single files on standalone hosting).

## How movement becomes music

The voice layer is editable in the Map step. Each of **pitch**, **dynamics** and **note density** can follow left ↔ right, back ↔ front, speed, distance from centre, or stay fixed, and each can be reversed (useful for mirrored practice videos). You can also choose the fastest repeated note (quarter or eighth) and the longest held note. The defaults below reproduce the original rules exactly. Formation rules are fixed for now.


| Layer | Movement | Music |
|---|---|---|
| Voices (one per dancer) | left ↔ right | pitch (stage width = 1–3 octaves) |
| | back ↔ front | dynamics |
| | crossing a pitch zone, or moving on the beat | new note |
| | standing still | held note |
| | identity | timbre |
| Formation (one chord per beat) | centroid left ↔ right | chord root (centre stage = tonic) |
| | mirror symmetry | triad / seventh / cluster |
| | dancers in a line | stacked fourths |
| | spread | voicing width |
| | centroid back ↔ front | chord dynamics |

## Pipeline

- **Detection**: YOLOv8n (ONNX, variable input size) on onnxruntime-web 1.30.0. Uses the graphics card through WebGPU when the browser supports it, otherwise WebAssembly on the CPU. Detector size Fast (320 px), Balanced (480) or Precise (640); Fast ran about 2.3× quicker than Precise on CPU in testing. Foot point = bottom centre of each box.
- **Floor mapping**: a homography from the four corner handles to a unit stage square.
- **Tracking**: fixed dancer count, Hungarian assignment per frame with constant-velocity prediction.
- **Composition**: eighth-note grid, see the table above (`src/core.js`, no DOM).
- **Rendering**: OpenSheetMusicDisplay 2.2.1 for the score, canvas for trajectory, feature strip and piano roll, Web Audio for playback.

## Files

| Path | Purpose |
|---|---|
| `index.html` | The built app |
| `yolov8n.onnx` | Person detector weights (Ultralytics YOLOv8n, COCO) |
| `ort-wasm-simd-threaded.wasm` | onnxruntime-web runtime |
| `src/core.js` | Geometry, tracking, composition, MusicXML and MIDI writers |
| `src/app.js` | Interface, audio, analysis loop, export, typeface settings |
| `src/style.css`, `src/page.html` | Styles and markup |
| `build.py` | Combines `src/` into `index.html` |

## Run locally or on GitHub Pages

```bash
python3 build.py
python3 -m http.server 8000   # open http://localhost:8000
```

Opening `index.html` straight from disk (`file://`) blocks the model download, so always serve it. For GitHub Pages, push the folder and enable Pages; every file is under GitHub's 100 MB limit.

## Troubleshooting

- **Nothing happens after choosing a video**: the browser can't decode it. Phone videos in HEVC/H.265 (.MOV) often won't play in Chrome on Windows. Convert to MP4 (H.264), e.g. with HandBrake, or set the phone camera to "Most Compatible". The app now says this on screen.
- **The terminal just says `Serving HTTP on ... port 8000`**: that means the server is running. Leave it open and browse to http://localhost:8000.
- **Dancers swap identities**: set the dancer count by hand and raise sampling to 12 fps.
- **Graphics-card engine**: WebGPU loads its runtime (about 27 MB) from jsDelivr on first use. Where that's blocked, analysis falls back to the CPU automatically; the Analyze step shows which engine ran.

## Typefaces

The **Aa** button opens typeface settings. Each viewer can pick a preset, type the name of a font installed on their computer, or load a font file (.woff2, .otf, .ttf). The choice stays in that browser.

To change the default for everyone on your own deployment, put the font files in a `fonts/` folder and add to the top of `src/style.css`:

```css
@font-face { font-family: "YourFont"; src: url("fonts/YourFont.woff2") format("woff2"); font-weight: 400 700; }
```

then put `"YourFont"` first in `--font-ui` (or `--font-mono`) and rebuild. Check the font's licence allows web embedding before you publish it.

## Licence

The YOLOv8 weights are licensed by Ultralytics under **AGPL-3.0** (see `LICENSE-YOLOv8`). Distributing this app with those weights means releasing the project under AGPL-3.0 too. For a closed or commercial release, get an Ultralytics enterprise licence or swap in a detector under a permissive licence.

onnxruntime-web (MIT) and OpenSheetMusicDisplay (BSD-3-Clause) load from jsDelivr. Geist and Geist Mono (SIL OFL) load from Google Fonts.
