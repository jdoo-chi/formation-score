(function () {
  'use strict';
  const C = window.Core;
  const $ = (id) => document.getElementById(id);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  window.addEventListener('error', e => { try { const t = document.getElementById('toast'); t.textContent = 'Something went wrong: ' + (e.message || 'unknown error'); t.hidden = false; } catch (x) { } });
  window.addEventListener('unhandledrejection', e => { console.error(e.reason); });

  // ---------- constants ----------
  const DANCER_COLORS = ['#b7a6ff', '#5ed2e4', '#ff8fa3', '#f0c36a', '#7ee0a6', '#8fb3ff', '#ff9f6b', '#e7e7f0', '#d68cf0', '#6be3c4', '#ffd27a', '#9aa6c8'];
  const INSTRUMENTS = [
    { name: 'Flute', program: 73, synth: 'flute' }, { name: 'Clarinet', program: 71, synth: 'clar' },
    { name: 'Violin', program: 40, synth: 'string' }, { name: 'Marimba', program: 12, synth: 'mallet' },
    { name: 'Trumpet', program: 56, synth: 'brass' }, { name: 'Vibraphone', program: 11, synth: 'vibe' },
    { name: 'Oboe', program: 68, synth: 'reed' }, { name: 'Harp', program: 46, synth: 'pluck' },
    { name: 'Cello', program: 42, synth: 'cello' }, { name: 'Horn', program: 60, synth: 'horn' },
    { name: 'Celesta', program: 8, synth: 'bell' }, { name: 'Bassoon', program: 70, synth: 'bassoon' }
  ];
  const CHORD_KIND = { sym: 'Symmetric · triad', semi: 'Near-symmetric · seventh', asym: 'Asymmetric · cluster', line: 'Line · stacked fourths' };
  const NOTE_NAMES = ['C', 'C♯', 'D', 'E♭', 'E', 'F', 'F♯', 'G', 'A♭', 'A', 'B♭', 'B'];
  const STEPS = ['upload', 'analyze', 'map', 'compose', 'export'];

  // ---------- state ----------
  const S = {
    source: 'demo', td: null, frames: null, duration: 0,
    corners: null, H: null, Hinv: null,
    names: [], inst: [], score: null,
    playing: false, t0: 0, cursor: 0, nextEv: 0, events: [], active: [],
    page: 0, perPage: 4, osmd: null, xml: '', analyzing: false, cancel: false,
    step: 'upload', trail: 'full', view: 'roll', overlay: true, fps: 8, detSize: 640, engine: 'auto'
  };
  const flash = {};

  // ---------- helpers ----------
  const fmt = (t) => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = t - m * 60; return `${m}:${s < 10 ? '0' : ''}${s.toFixed(1)}`; };
  function toast(msg) { const el = $('toast'); el.textContent = msg; el.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(() => el.hidden = true, 3400); }
  function cssVar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
  function fitCanvas(c) {
    const r = c.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    return { w: r.width, h: r.height, dpr };
  }
  function settings() {
    return {
      bpm: Math.min(240, Math.max(40, +$('bpm').value || 120)),
      offset: Math.max(0, +$('offset').value || 0),
      root: +$('key').value, mode: $('mode').value, melodySpan: +$('span').value || 2,
      duration: S.duration, map: readMap()
    };
  }

  // ---------- segmented controls ----------
  function segment(id, onPick) {
    const box = $(id), attr = box.getAttribute('role') === 'tablist' ? 'aria-selected' : 'aria-checked';
    const btns = $$('button', box);
    const pick = (b, fire) => { btns.forEach(x => { x.setAttribute(attr, x === b ? 'true' : 'false'); x.tabIndex = x === b ? 0 : -1; }); if (fire) onPick(b.dataset.v); };
    btns.forEach(b => {
      b.tabIndex = b.getAttribute(attr) === 'true' ? 0 : -1;
      b.addEventListener('click', () => pick(b, true));
      b.addEventListener('keydown', e => {
        const i = btns.indexOf(b), d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
        if (d) { e.preventDefault(); const n = btns[(i + d + btns.length) % btns.length]; n.focus(); pick(n, true); }
      });
    });
  }
  segment('fpsSeg', v => { S.fps = +v; });
  segment('sizeSeg', v => { S.detSize = +v; });
  segment('trailSeg', v => { S.trail = v; });
  segment('viewTabs', v => { S.view = v; $('rollPanel').hidden = v !== 'roll'; $('scorePanel').hidden = v !== 'score'; if (v === 'score') renderScore(); });

  // ---------- workflow steps ----------
  function setStep(name) {
    S.step = name;
    $$('.step').forEach(b => b.dataset.step === name ? b.setAttribute('aria-current', 'step') : b.removeAttribute('aria-current'));
    $$('.pane').forEach(p => p.hidden = p.dataset.pane !== name);
    if (name !== 'analyze' && calibrating) setCalibrating(false);
    refreshSteps();
  }
  function refreshSteps() {
    const done = {
      upload: S.source === 'video' || S.source === 'demo',
      analyze: S.source === 'demo' || !!(S.frames && S.td),
      map: !!S.score, compose: !!S.score, export: false
    };
    $$('.step').forEach(b => b.dataset.done = done[b.dataset.step] && b.dataset.step !== S.step ? 'true' : 'false');
  }
  $$('.step').forEach(b => b.addEventListener('click', () => {
    setStep(b.dataset.step);
    if (window.innerWidth <= 1100) document.querySelector('.inspector').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }));

  // ---------- mapping editor ----------
  const MAP_KEYS = ['pitch', 'dynamics', 'density'];
  const MAP_ENDS = { x: ['stage left', 'stage right'], y: ['upstage', 'downstage'], speed: ['standing still', 'moving fast'], center: ['centre stage', 'the edges'] };
  const cap = (k) => k[0].toUpperCase() + k.slice(1);
  function readMap() {
    const m = {};
    MAP_KEYS.forEach(k => { m[k] = { src: $('map' + cap(k) + 'Src').value, inv: $('map' + cap(k) + 'Inv').checked }; });
    m.density.fastest = $('mapDensityFastest').value;
    m.maxHold = +$('mapHold').value;
    return m;
  }
  function writeMap(m) {
    m = C.normMap(m);
    MAP_KEYS.forEach(k => { $('map' + cap(k) + 'Src').value = m[k].src; $('map' + cap(k) + 'Inv').checked = m[k].inv; });
    $('mapDensityFastest').value = m.density.fastest; $('mapHold').value = String(m.maxHold);
  }
  function mapHints() {
    const m = readMap(), D = C.DEFAULT_MAP;
    MAP_KEYS.forEach(k => {
      const r = m[k], ends = MAP_ENDS[r.src], el = $('map' + cap(k) + 'Hint');
      const [lo, hi] = ends ? (r.inv ? [ends[1], ends[0]] : ends) : [];
      $('map' + cap(k) + 'Inv').disabled = r.src === 'fixed';
      if (k === 'pitch') el.textContent = ends ? `Low at ${lo} · high at ${hi}` : 'Everyone stays on one pitch';
      if (k === 'dynamics') el.textContent = ends ? `Soft at ${lo} · loud at ${hi}` : 'Same loudness throughout';
      if (k === 'density') el.textContent = ends ? `Held at ${lo} · repeated at ${hi}` : `Re-struck on every ${m.density.fastest === 'eighth' ? 'eighth' : 'beat'}`;
      el.closest('.maprow').classList.toggle('changed', r.src !== D[k].src || r.inv !== D[k].inv);
    });
  }
  function initMap() {
    let saved = null; try { saved = JSON.parse(localStorage.getItem('fs-map')); } catch (e) { }
    writeMap(saved || C.DEFAULT_MAP); mapHints();
    const onChange = () => {
      mapHints();
      try { localStorage.setItem('fs-map', JSON.stringify(readMap())); } catch (e) { }
      const was = S.playing; if (was) pause(); recompose(); if (was) play();
    };
    MAP_KEYS.forEach(k => { $('map' + cap(k) + 'Src').addEventListener('change', onChange); $('map' + cap(k) + 'Inv').addEventListener('change', onChange); });
    $('mapDensityFastest').addEventListener('change', onChange); $('mapHold').addEventListener('change', onChange);
    $('mapReset').addEventListener('click', () => { writeMap(C.DEFAULT_MAP); onChange(); });
  }

  // ---------- composing ----------
  function ensureNames(n) {
    while (S.names.length < n) S.names.push(`Dancer ${S.names.length + 1}`);
    while (S.inst.length < n) S.inst.push(S.inst.length % INSTRUMENTS.length);
    S.names.length = n; S.inst.length = n;
  }
  function recompose() {
    if (!S.td || !S.td.tracks.length) return;
    ensureNames(S.td.tracks.length);
    S.score = C.compose(S.td, settings());
    buildEvents(); buildXML(); renderLegend(); renderStats(); renderScore();
    $('scrub').max = S.duration.toFixed(2);
    $('durLabel').textContent = '/ ' + fmt(S.duration);
    refreshSteps();
  }
  function parts() {
    const sc = S.score;
    const P = sc.melodies.map((m, i) => ({
      name: S.names[i], instrument: INSTRUMENTS[S.inst[i]].name, program: INSTRUMENTS[S.inst[i]].program, clef: 'G',
      events: m.map(n => ({ start: n.start, dur: n.dur, notes: [n.midi], vel: n.vel }))
    }));
    P.push({ name: 'Formation', instrument: 'String Ensemble', program: 48, clef: 'F', events: sc.chords });
    return P;
  }
  function buildXML() {
    const s = settings();
    S.xml = C.toMusicXML(parts(), S.score.nSteps, s.bpm, C.keyFifths(s.root, s.mode), S.source === 'demo' ? 'Sample choreography' : (S.fileName || 'Formation Score'));
  }
  function buildEvents() {
    const sc = S.score, s = sc.settings, ev = [];
    sc.melodies.forEach((m, d) => m.forEach(n => {
      const t = s.offset + n.start * sc.stepDur;
      const p = C.posAt(S.td, t)[d];
      ev.push({ t, dur: n.dur * sc.stepDur, midi: n.midi, vel: n.vel, synth: INSTRUMENTS[S.inst[d]].synth, pan: (p ? p.x : 0.5) * 1.6 - 0.8, layer: 'mel', d });
    }));
    sc.chords.forEach(c => c.notes.forEach(m => ev.push({ t: s.offset + c.start * sc.stepDur, dur: c.dur * sc.stepDur, midi: m, vel: c.vel, synth: 'pad', pan: 0, layer: 'chord' })));
    ev.sort((a, b) => a.t - b.t);
    S.events = ev;
  }

  // ---------- audio (unchanged engine) ----------
  let actx = null, master = null;
  function audio() {
    if (!actx) {
      actx = new (window.AudioContext || window.webkitAudioContext)();
      master = actx.createGain(); master.gain.value = 0.55;
      const comp = actx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 4;
      master.connect(comp); comp.connect(actx.destination);
    }
    return actx;
  }
  const RECIPES = {
    flute: { w: ['sine', 'triangle'], mix: [1, 0.25], lp: 5000, a: 0.06, r: 0.15, vib: 4 },
    clar: { w: ['square'], lp: 1500, q: 1, a: 0.03, r: 0.1 },
    string: { w: ['sawtooth'], lp: 2800, a: 0.09, r: 0.2, vib: 6 },
    mallet: { w: ['sine', 'sine'], mult: [1, 4], mix: [1, 0.18], decay: 0.7, a: 0.004 },
    brass: { w: ['sawtooth'], lp: 900, lpEnv: 2800, a: 0.05, r: 0.1 },
    vibe: { w: ['sine', 'sine'], mult: [1, 3], mix: [1, 0.1], decay: 1.6, trem: 5.5, a: 0.005 },
    reed: { w: ['sawtooth', 'square'], mix: [0.6, 0.4], lp: 2100, q: 4, a: 0.04, r: 0.1 },
    pluck: { w: ['triangle'], decay: 0.8, a: 0.003 },
    cello: { w: ['sawtooth'], lp: 1100, a: 0.08, r: 0.25, vib: 5 },
    horn: { w: ['triangle', 'sine'], mix: [0.7, 0.5], lp: 1300, a: 0.08, r: 0.2 },
    bell: { w: ['sine', 'sine'], mult: [1, 2.76], mix: [1, 0.35], decay: 1.4, a: 0.002 },
    bassoon: { w: ['square'], lp: 800, q: 2, a: 0.05, r: 0.12 },
    pad: { w: ['sawtooth', 'sawtooth'], det: [-7, 7], mix: [0.5, 0.5], lp: 1100, a: 0.25, r: 0.45 }
  };
  function playNote(e, when) {
    const R = RECIPES[e.synth] || RECIPES.flute, ctx = actx;
    const f = 440 * Math.pow(2, (e.midi - 69) / 12);
    const peak = (e.vel / 127) * (e.layer === 'chord' ? 0.07 : 0.16);
    const g = ctx.createGain(); g.gain.value = 0;
    const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    let out = g;
    if (pan) { pan.pan.value = Math.max(-1, Math.min(1, e.pan || 0)); g.connect(pan); out = pan; }
    out.connect(master);
    let dest = g;
    if (R.lp) {
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = R.lp; lp.Q.value = R.q || 0.7;
      if (R.lpEnv) { lp.frequency.setValueAtTime(R.lp, when); lp.frequency.linearRampToValueAtTime(R.lpEnv, when + 0.08); lp.frequency.linearRampToValueAtTime(R.lp * 1.5, when + 0.4); }
      lp.connect(g); dest = lp;
    }
    const end = R.decay ? when + Math.max(R.decay, 0.2) : when + e.dur + (R.r || 0.1);
    const oscs = R.w.map((type, i) => {
      const o = ctx.createOscillator(); o.type = type;
      o.frequency.value = f * ((R.mult && R.mult[i]) || 1);
      if (R.det) o.detune.value = R.det[i];
      const og = ctx.createGain(); og.gain.value = (R.mix && R.mix[i]) || 1;
      o.connect(og); og.connect(dest);
      o.start(when); o.stop(end + 0.05);
      return o;
    });
    if (R.vib) {
      const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = 5.2; lg.gain.value = R.vib;
      l.connect(lg); oscs.forEach(o => lg.connect(o.detune)); l.start(when + 0.15); l.stop(end + 0.05); oscs.push(l);
    }
    g.gain.setValueAtTime(0, when); g.gain.linearRampToValueAtTime(peak, when + R.a);
    if (R.decay) g.gain.exponentialRampToValueAtTime(0.0008, end);
    else { g.gain.setValueAtTime(peak * 0.85, when + Math.max(R.a, e.dur - 0.02)); g.gain.linearRampToValueAtTime(0, end); }
    if (R.trem) { const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = R.trem; lg.gain.value = peak * 0.3; l.connect(lg); lg.connect(g.gain); l.start(when); l.stop(end); oscs.push(l); }
    S.active.push({ g, oscs, end });
  }
  function silence() {
    if (!actx) return;
    const now = actx.currentTime;
    S.active.forEach(n => { try { n.g.gain.cancelScheduledValues(now); n.g.gain.setValueAtTime(n.g.gain.value, now); n.g.gain.linearRampToValueAtTime(0, now + 0.05); n.oscs.forEach(o => o.stop(now + 0.08)); } catch (e) { } });
    S.active = [];
  }

  // ---------- transport ----------
  const video = $('video');
  function now() { return S.playing ? actx.currentTime - S.t0 : S.cursor; }
  async function play() {
    if (!S.score) return;
    audio(); await actx.resume();
    if (S.cursor >= S.duration - 0.05) S.cursor = 0;
    S.t0 = actx.currentTime - S.cursor + 0.05;
    S.nextEv = S.events.findIndex(e => e.t >= S.cursor - 1e-3); if (S.nextEv < 0) S.nextEv = S.events.length;
    S.playing = true;
    if (S.source === 'video') { video.currentTime = S.cursor; video.muted = !$('origAudio').checked; video.play().catch(() => { }); }
    $('playBtn').setAttribute('aria-pressed', 'true'); $('playLabel').textContent = 'Pause';
    schedule();
  }
  function pause() {
    S.cursor = now(); S.playing = false;
    if (S.source === 'video') video.pause();
    silence();
    $('playBtn').setAttribute('aria-pressed', 'false'); $('playLabel').textContent = 'Play';
  }
  function seek(t) {
    const was = S.playing; if (was) pause();
    S.cursor = Math.max(0, Math.min(S.duration, t));
    if (S.source === 'video') video.currentTime = S.cursor;
    if (was) play();
  }
  function schedule() {
    if (!S.playing) return;
    const t = now(), horizon = t + 0.2;
    const mel = $('layerMel').checked, chd = $('layerChord').checked;
    while (S.nextEv < S.events.length && S.events[S.nextEv].t < horizon) {
      const e = S.events[S.nextEv++];
      if (e.t < t - 0.05) continue;
      if ((e.layer === 'mel' && !mel) || (e.layer === 'chord' && !chd)) continue;
      if (e.layer === 'mel' && e.d != null) flash[e.d] = e.t;
      playNote(e, S.t0 + e.t);
    }
    S.active = S.active.filter(n => n.end > actx.currentTime - 0.2);
    if (S.source === 'video' && !video.paused && Math.abs(video.currentTime - t) > 0.15) video.currentTime = t;
    if (t >= S.duration) { pause(); S.cursor = 0; }
    setTimeout(schedule, 25);
  }

  // ---------- trajectory (centrepiece) ----------
  const map = $('map'), mctx = map.getContext('2d');
  function stageRect(w, h) {
    const padL = 28, padR = 28, padT = 26, padB = 40, ratio = 1.6;
    let sw = w - padL - padR, sh = sw / ratio;
    if (sh > h - padT - padB) { sh = h - padT - padB; sw = sh * ratio; }
    const x0 = (w - sw) / 2, y0 = padT + Math.max(0, (h - padT - padB - sh) / 2);
    return { x0, y0, sw, sh, X: x => x0 + x * sw, Y: y => y0 + y * sh };
  }
  function hull(pts) {
    const p = pts.slice().sort((a, b) => a.x - b.x || a.y - b.y);
    if (p.length < 3) return p;
    const cr = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
    const lo = [], up = [];
    p.forEach(q => { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); });
    p.slice().reverse().forEach(q => { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); });
    return lo.slice(0, -1).concat(up.slice(0, -1));
  }
  let pathCache = null;
  function drawMap(t) {
    const { w, h, dpr } = fitCanvas(map);
    const g = mctx; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = cssVar('--floor'); g.fillRect(0, 0, w, h);
    const { x0, y0, sw, sh, X, Y } = stageRect(w, h);
    const ui = cssVar('--font-ui'), mono = cssVar('--font-mono');
    // floor grid: eighths across, quarters deep
    g.lineWidth = 1;
    for (let k = 1; k < 8; k++) { g.strokeStyle = k === 4 ? 'rgba(183,166,255,.28)' : 'rgba(255,255,255,.05)'; const x = Math.round(X(k / 8)) + 0.5; g.beginPath(); g.moveTo(x, y0); g.lineTo(x, y0 + sh); g.stroke(); }
    for (let k = 1; k < 4; k++) { g.strokeStyle = 'rgba(255,255,255,.05)'; const y = Math.round(Y(k / 4)) + 0.5; g.beginPath(); g.moveTo(x0, y); g.lineTo(x0 + sw, y); g.stroke(); }
    g.strokeStyle = 'rgba(255,255,255,.14)'; g.strokeRect(Math.round(x0) + 0.5, Math.round(y0) + 0.5, Math.round(sw), Math.round(sh));
    // downstage numbers, as taped on a real stage
    g.fillStyle = cssVar('--text-3'); g.font = `500 10px ${mono}`; g.textAlign = 'center';
    for (let k = -4; k <= 4; k++) { const x = X(0.5 + k / 8); g.fillRect(Math.round(x), y0 + sh, 1, 5); g.fillText(String(Math.abs(k)), x, y0 + sh + 17); }
    g.font = `500 10px ${ui}`; g.fillStyle = cssVar('--text-3');
    g.fillText('AUDIENCE', X(0.5), y0 + sh + 32);
    g.textAlign = 'left'; g.fillText('UPSTAGE', x0, y0 - 9);
    if (!S.td) return;
    const P = C.posAt(S.td, t);
    // full paths, drawn once per data set
    if (S.trail === 'full') {
      const key = S.td.times.length + ':' + Math.round(sw) + ':' + Math.round(sh);
      if (!pathCache || pathCache.key !== key || pathCache.td !== S.td) {
        pathCache = { key, td: S.td, paths: S.td.tracks.map(P => P.filter((p, i) => i % 2 === 0 && p.on)) };
      }
      g.lineWidth = 1;
      pathCache.paths.forEach((pts, k) => {
        g.strokeStyle = DANCER_COLORS[k % 12]; g.globalAlpha = 0.16; g.beginPath();
        pts.forEach((p, i) => i ? g.lineTo(X(p.x), Y(p.y)) : g.moveTo(X(p.x), Y(p.y)));
        g.stroke();
      });
      g.globalAlpha = 1;
    }
    // formation hull
    const on = P.filter(p => p.on);
    if (on.length > 2) {
      const hl = hull(on);
      g.beginPath(); hl.forEach((p, i) => i ? g.lineTo(X(p.x), Y(p.y)) : g.moveTo(X(p.x), Y(p.y))); g.closePath();
      g.fillStyle = 'rgba(124,132,255,.07)'; g.fill();
      g.strokeStyle = 'rgba(124,132,255,.35)'; g.setLineDash([2, 4]); g.lineWidth = 1; g.stroke(); g.setLineDash([]);
    }
    // recent trail (2 s), fading
    S.td.tracks.forEach((tr, k) => {
      const col = DANCER_COLORS[k % 12]; let prev = null;
      for (let i = 0; i <= 20; i++) {
        const q = C.posAt(S.td, t - 2 + i * 0.1)[k];
        if (prev && q.on) { g.strokeStyle = col; g.globalAlpha = (i / 20) * 0.9; g.lineWidth = 1 + (i / 20) * 1.8; g.beginPath(); g.moveTo(X(prev.x), Y(prev.y)); g.lineTo(X(q.x), Y(q.y)); g.stroke(); }
        prev = q;
      }
    });
    g.globalAlpha = 1;
    // centroid
    if (on.length > 1) {
      const cx = on.reduce((a, p) => a + p.x, 0) / on.length, cy = on.reduce((a, p) => a + p.y, 0) / on.length;
      g.strokeStyle = cssVar('--cyan'); g.lineWidth = 1.2;
      g.beginPath(); g.moveTo(X(cx) - 6, Y(cy)); g.lineTo(X(cx) + 6, Y(cy)); g.moveTo(X(cx), Y(cy) - 6); g.lineTo(X(cx), Y(cy) + 6); g.stroke();
      g.beginPath(); g.arc(X(cx), Y(cy), 9, 0, 7); g.globalAlpha = 0.4; g.stroke(); g.globalAlpha = 1;
    }
    // dancers
    P.forEach((p, k) => {
      const x = X(p.x), y = Y(p.y), col = DANCER_COLORS[k % 12];
      g.globalAlpha = p.on ? 1 : 0.25;
      const age = flash[k] != null ? (t - flash[k]) : 9;
      if (S.playing && age >= 0 && age < 0.4) { g.strokeStyle = col; g.lineWidth = 1.2; g.globalAlpha = (1 - age / 0.4) * 0.8; g.beginPath(); g.arc(x, y, 8 + age * 40, 0, 7); g.stroke(); g.globalAlpha = p.on ? 1 : 0.25; }
      g.fillStyle = col; g.beginPath(); g.arc(x, y, 5.5, 0, 7); g.fill();
      g.strokeStyle = col; g.lineWidth = 1; g.globalAlpha *= 0.4; g.beginPath(); g.arc(x, y, 10, 0, 7); g.stroke();
      g.globalAlpha = p.on ? 0.95 : 0.25;
      g.font = `500 11px ${ui}`; g.fillStyle = cssVar('--text'); g.textAlign = 'left';
      g.fillText(S.names[k] || '', x + 13, y + 4);
    });
    g.globalAlpha = 1;
  }

  // ---------- formation feature strip ----------
  const feats = $('feats'), fctx = feats.getContext('2d');
  function drawFeats(t) {
    const { w, h, dpr } = fitCanvas(feats);
    const g = fctx; g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
    if (!S.score) return;
    const F = S.score.feats, s = S.score.settings, beat = S.score.stepDur * 2;
    const rows = [
      { label: 'Centroid', key: 'cx', min: 0, max: 1, col: cssVar('--cyan'), fmt: v => v < 0.47 ? 'stage left' : v > 0.53 ? 'stage right' : 'centre' },
      { label: 'Symmetry', key: 'symmetry', min: 0, max: 1, col: cssVar('--lavender'), fmt: v => Math.round(v * 100) + '%' },
      { label: 'Spread', key: 'spread', min: 0, max: 0.6, col: cssVar('--indigo'), fmt: v => v.toFixed(2) }
    ];
    const labW = 78, valW = 80, plotW = w - labW - valW, rh = h / rows.length;
    const ui = cssVar('--font-ui'), mono = cssVar('--font-mono');
    const tx = time => labW + (time / Math.max(0.01, S.duration)) * plotW;
    const cur = F[Math.floor((t - s.offset) / beat)];
    rows.forEach((r, i) => {
      const y0 = i * rh + 4, ph = rh - 10;
      g.fillStyle = cssVar('--text-3'); g.font = `500 11px ${ui}`; g.textAlign = 'left'; g.fillText(r.label, 0, y0 + ph / 2 + 4);
      g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1; g.beginPath(); g.moveTo(labW, Math.round(y0 + ph) + 0.5); g.lineTo(labW + plotW, Math.round(y0 + ph) + 0.5); g.stroke();
      if (r.key === 'cx') { g.setLineDash([2, 3]); g.beginPath(); g.moveTo(labW, y0 + ph / 2); g.lineTo(labW + plotW, y0 + ph / 2); g.stroke(); g.setLineDash([]); }
      const Yv = v => y0 + ph - (Math.min(r.max, Math.max(r.min, v)) - r.min) / (r.max - r.min) * ph;
      // area + line
      g.beginPath(); let started = false, lastX = labW;
      F.forEach((f, k) => { if (!f) return; const x = tx(s.offset + k * beat), y = Yv(f[r.key]); if (!started) { g.moveTo(x, y); started = true; } else g.lineTo(x, y); lastX = x; });
      if (started) {
        g.strokeStyle = r.col; g.lineWidth = 1.3; g.stroke();
        g.lineTo(lastX, y0 + ph); g.lineTo(tx(s.offset), y0 + ph); g.closePath();
        g.globalAlpha = 0.08; g.fillStyle = r.col; g.fill(); g.globalAlpha = 1;
      }
      g.fillStyle = cur ? cssVar('--text') : cssVar('--text-3'); g.font = `500 11px ${mono}`; g.textAlign = 'right';
      g.fillText(cur ? r.fmt(cur[r.key]) : '—', w, y0 + ph / 2 + 4);
      if (cur) { g.fillStyle = r.col; g.beginPath(); g.arc(tx(t), Yv(cur[r.key]), 2.8, 0, 7); g.fill(); }
    });
    g.strokeStyle = cssVar('--text'); g.globalAlpha = 0.5; g.lineWidth = 1;
    g.beginPath(); g.moveTo(Math.round(tx(t)) + 0.5, 0); g.lineTo(Math.round(tx(t)) + 0.5, h); g.stroke(); g.globalAlpha = 1;
  }
  feats.addEventListener('click', e => {
    const r = feats.getBoundingClientRect(), labW = 78, valW = 80, x = e.clientX - r.left - labW;
    if (x >= 0 && x <= r.width - labW - valW) seek(x / (r.width - labW - valW) * S.duration);
  });

  // ---------- piano roll ----------
  const roll = $('roll'), rctx = roll.getContext('2d');
  const ROLL_BARS = 6;
  function rollWindow(w) {
    const sc = S.score, barDur = sc.stepDur * 8, span = barDur * ROLL_BARS, s = sc.settings;
    const t = now();
    let start = t - span * 0.25;
    start = Math.max(Math.min(start, S.duration - span), Math.min(0, s.offset));
    return { start, span, barDur, keyW: 44, plotW: w - 44 };
  }
  function drawRoll() {
    const { w, h, dpr } = fitCanvas(roll);
    const g = rctx; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = cssVar('--bg'); g.fillRect(0, 0, w, h);
    if (!S.score) {
      g.fillStyle = cssVar('--text-3'); g.font = `500 12px ${cssVar('--font-ui')}`; g.textAlign = 'center';
      g.fillText(S.source === 'video' ? 'Notes appear here after the analysis.' : 'No composition yet.', w / 2, h / 2);
      return;
    }
    const sc = S.score, s = sc.settings, t = now();
    const { start, span, barDur, keyW, plotW } = rollWindow(w);
    const ui = cssVar('--font-ui'), mono = cssVar('--font-mono');
    const X = time => keyW + (time - start) / span * plotW;
    const rulerH = 20, gap = 8, chordH = Math.round((h - rulerH) * 0.3), melH = h - rulerH - chordH - gap;
    let lo = 127, hi = 0;
    sc.melodies.forEach(m => m.forEach(n => { lo = Math.min(lo, n.midi); hi = Math.max(hi, n.midi); }));
    if (lo > hi) { lo = 60; hi = 84; }
    lo -= 1; hi += 1;
    let clo = 127, chi = 0; sc.chords.forEach(c => c.notes.forEach(m => { clo = Math.min(clo, m); chi = Math.max(chi, m); }));
    if (clo > chi) { clo = 36; chi = 60; }
    clo -= 1; chi += 1;
    const melY = m => rulerH + (hi - m) / (hi - lo + 1) * melH, melRow = melH / (hi - lo + 1);
    const chY = m => rulerH + melH + gap + (chi - m) / (chi - clo + 1) * chordH, chRow = chordH / (chi - clo + 1);
    // pitch rows: shade the black keys and mark each C
    for (let m = lo; m <= hi; m++) {
      const y = melY(m);
      if ([1, 3, 6, 8, 10].includes(m % 12)) { g.fillStyle = 'rgba(255,255,255,.018)'; g.fillRect(keyW, y, plotW, melRow); }
      if (m % 12 === 0) { g.fillStyle = cssVar('--text-3'); g.font = `500 10px ${mono}`; g.textAlign = 'right'; g.fillText('C' + (Math.floor(m / 12) - 1), keyW - 8, y + melRow - 1); g.fillStyle = 'rgba(255,255,255,.06)'; g.fillRect(keyW, Math.round(y + melRow), plotW, 1); }
    }
    g.fillStyle = 'rgba(94,210,228,.04)'; g.fillRect(keyW, rulerH + melH + gap, plotW, chordH);
    g.fillStyle = cssVar('--text-3'); g.font = `500 10px ${ui}`; g.textAlign = 'right'; g.fillText('Chords', keyW - 8, rulerH + melH + gap + 12);
    // bars and beats
    const firstBar = Math.floor((start - s.offset) / barDur);
    for (let b = firstBar; b <= firstBar + ROLL_BARS + 1; b++) {
      for (let q = 0; q < 4; q++) {
        const time = s.offset + b * barDur + q * barDur / 4, x = Math.round(X(time)) + 0.5;
        if (x < keyW || x > w) continue;
        g.strokeStyle = q === 0 ? 'rgba(255,255,255,.12)' : 'rgba(255,255,255,.04)'; g.lineWidth = 1;
        g.beginPath(); g.moveTo(x, q === 0 ? 4 : rulerH); g.lineTo(x, h); g.stroke();
        if (q === 0 && b >= 0) { g.fillStyle = cssVar('--text-2'); g.font = `500 10px ${mono}`; g.textAlign = 'left'; g.fillText(String(b + 1), x + 4, 13); }
      }
    }
    // notes
    const mel = $('layerMel').checked, chd = $('layerChord').checked;
    const rr = (x, y, ww, hh, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, ww, hh, r) : g.rect(x, y, ww, hh); };
    sc.melodies.forEach((m, d) => {
      const col = DANCER_COLORS[d % 12];
      m.forEach(n => {
        const ts = s.offset + n.start * sc.stepDur, te = ts + n.dur * sc.stepDur;
        if (te < start || ts > start + span) return;
        const x = Math.max(keyW, X(ts)), x2 = Math.min(w, X(te)), y = melY(n.midi);
        const live = t >= ts && t < te;
        g.globalAlpha = (mel ? 1 : 0.25) * (0.45 + 0.55 * n.vel / 127);
        g.fillStyle = col; rr(x + 0.5, y + 0.5, Math.max(2, x2 - x - 1.5), Math.max(2, melRow - 1), 2); g.fill();
        if (live && S.playing) { g.globalAlpha = 1; g.strokeStyle = '#fff'; g.lineWidth = 1; g.stroke(); }
      });
    });
    sc.chords.forEach(c => {
      const ts = s.offset + c.start * sc.stepDur, te = ts + c.dur * sc.stepDur;
      if (te < start || ts > start + span) return;
      const x = Math.max(keyW, X(ts)), x2 = Math.min(w, X(te));
      g.globalAlpha = chd ? 0.75 : 0.2; g.fillStyle = cssVar('--cyan');
      c.notes.forEach(m => { rr(x + 0.5, chY(m) + 0.5, Math.max(2, x2 - x - 1.5), Math.max(2, chRow - 1), 1.5); g.fill(); });
    });
    g.globalAlpha = 1;
    // playhead
    const px = Math.round(X(t)) + 0.5;
    if (px >= keyW) {
      g.strokeStyle = cssVar('--text'); g.lineWidth = 1; g.beginPath(); g.moveTo(px, 0); g.lineTo(px, h); g.stroke();
      g.fillStyle = cssVar('--text'); g.beginPath(); g.moveTo(px - 5, 0); g.lineTo(px + 5, 0); g.lineTo(px, 7); g.closePath(); g.fill();
    }
  }
  roll.addEventListener('click', e => {
    if (!S.score) return;
    const r = roll.getBoundingClientRect(), win = rollWindow(r.width), x = e.clientX - r.left - win.keyW;
    if (x >= 0) seek(win.start + x / win.plotW * win.span);
  });

  // ---------- video overlay (calibration + tracked feet) ----------
  const ov = $('overlay'), octx = ov.getContext('2d');
  let calibrating = false, drag = -1;
  function videoRect() {
    const r = ov.getBoundingClientRect(), vw = video.videoWidth || 16, vh = video.videoHeight || 9;
    const s = Math.min(r.width / vw, r.height / vh);
    return { s, x: (r.width - vw * s) / 2, y: (r.height - vh * s) / 2, w: r.width, h: r.height };
  }
  function defaultCorners() {
    const vw = video.videoWidth, vh = video.videoHeight;
    return [[vw * 0.16, vh * 0.5], [vw * 0.84, vh * 0.5], [vw * 0.99, vh * 0.96], [vw * 0.01, vh * 0.96]];
  }
  function drawOverlay(t) {
    const { w, h, dpr } = fitCanvas(ov);
    octx.setTransform(dpr, 0, 0, dpr, 0, 0); octx.clearRect(0, 0, w, h);
    if (S.source !== 'video' || !S.corners) return;
    const R = videoRect(), V = ([x, y]) => [R.x + x * R.s, R.y + y * R.s];
    const ui = cssVar('--font-ui'), mono = cssVar('--font-mono');
    const pts = S.corners.map(V);
    if (calibrating || S.overlay) {
      octx.strokeStyle = calibrating ? cssVar('--lavender') : 'rgba(183,166,255,.35)';
      octx.lineWidth = calibrating ? 1.5 : 1; octx.setLineDash(calibrating ? [] : [3, 4]);
      octx.beginPath(); pts.forEach((p, i) => i ? octx.lineTo(p[0], p[1]) : octx.moveTo(p[0], p[1])); octx.closePath(); octx.stroke();
      octx.setLineDash([]);
      if (calibrating) { octx.fillStyle = 'rgba(124,132,255,.08)'; octx.fill(); }
    }
    if (calibrating) {
      pts.forEach((p, i) => {
        octx.fillStyle = cssVar('--lavender'); octx.beginPath(); octx.arc(p[0], p[1], 9, 0, 7); octx.fill();
        octx.strokeStyle = 'rgba(10,11,16,.8)'; octx.lineWidth = 2; octx.stroke();
        octx.fillStyle = '#120d24'; octx.font = `600 11px ${mono}`; octx.textAlign = 'center'; octx.fillText(String(i + 1), p[0], p[1] + 4);
      });
      return;
    }
    if (!S.overlay || !S.td || !S.Hinv) return;
    const T = S.td.times; let i = 0, hi = T.length - 1;
    while (hi - i > 1) { const m = (i + hi) >> 1; if (T[m] <= t) i = m; else hi = m; }
    if (Math.abs((T[hi] || 0) - t) < Math.abs((T[i] || 0) - t)) i = hi;
    S.td.tracks.forEach((P, k) => {
      const p = P[i]; if (!p) return;
      let ix = p.ix, iy = p.iy, solid = p.ok;
      if (ix == null) { [ix, iy] = C.applyH(S.Hinv, p.x, p.y); solid = false; }
      const [x, y] = V([ix, iy]), col = DANCER_COLORS[k % 12];
      octx.globalAlpha = p.on ? 1 : 0.35;
      octx.strokeStyle = col; octx.lineWidth = 1.6; octx.setLineDash(solid ? [] : [3, 3]);
      octx.beginPath(); octx.ellipse(x, y, 13, 4.5, 0, 0, 7); octx.stroke(); octx.setLineDash([]);
      octx.font = `500 11px ${ui}`; octx.textAlign = 'center';
      const label = S.names[k], tw = octx.measureText(label).width + 10;
      octx.fillStyle = 'rgba(10,11,16,.78)'; octx.fillRect(x - tw / 2, y + 8, tw, 16);
      octx.fillStyle = col; octx.fillText(label, x, y + 20);
    });
    octx.globalAlpha = 1;
  }
  function evPoint(e) {
    const r = ov.getBoundingClientRect(), R = videoRect();
    return [(e.clientX - r.left - R.x) / R.s, (e.clientY - r.top - R.y) / R.s];
  }
  ov.addEventListener('pointerdown', e => {
    if (!calibrating || !S.corners) return;
    const p = evPoint(e), R = videoRect();
    let best = -1, bd = 30 / R.s;
    S.corners.forEach((c, i) => { const d = Math.hypot(c[0] - p[0], c[1] - p[1]); if (d < bd) { bd = d; best = i; } });
    if (best >= 0) { drag = best; ov.setPointerCapture(e.pointerId); e.preventDefault(); }
  });
  ov.addEventListener('pointermove', e => {
    if (drag < 0) return;
    const p = evPoint(e);
    S.corners[drag] = [Math.max(0, Math.min(video.videoWidth, p[0])), Math.max(0, Math.min(video.videoHeight, p[1]))];
  });
  ov.addEventListener('pointerup', () => { if (drag >= 0) { drag = -1; updateHomography(); if (S.frames) retrack(); } });
  function updateHomography() { S.H = C.homography(S.corners, C.UNIT); S.Hinv = S.H ? C.invertH(S.H) : null; }
  function setCalibrating(on) {
    calibrating = on;
    $('calibBtn').setAttribute('aria-pressed', on ? 'true' : 'false');
    $('calibBtn').querySelector('span').textContent = on ? 'Finish corners' : 'Adjust floor corners';
    $('calibHint').hidden = !on;
    ov.style.pointerEvents = on ? 'auto' : 'none';
  }
  $('calibBtn').addEventListener('click', () => setCalibrating(!calibrating));
  $('calibDone').addEventListener('click', () => setCalibrating(false));
  $('overlayToggle').addEventListener('change', e => { S.overlay = e.target.checked; });

  // ---------- video loading ----------
  // Shows why a video could not be opened, in the footage frame and the Upload step, not only as a toast.
  function videoProblem(msg) {
    clearTimeout(S.loadTimer);
    const box = $('videoEmpty');
    box.hidden = false;
    box.querySelector('p').textContent = 'This video could not be opened';
    box.querySelector('span').textContent = msg;
    $('uploadMsg').textContent = msg; $('uploadMsg').hidden = false; $('factLen').textContent = '—';
    toast(msg);
  }
  const FORMAT_HELP = 'Convert it to MP4 (H.264), for example with HandBrake, or record with the camera’s “Most Compatible” setting.';
  function loadVideo(file) {
    if (!file) return;
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    const looksVideo = /^video\//.test(file.type) || ['mp4', 'm4v', 'mov', 'webm', 'mkv', 'avi', 'ogv'].includes(ext);
    if (!looksVideo) { videoProblem(`“${file.name}” is not a video file.`); return; }
    pause();
    if (S.videoURL) URL.revokeObjectURL(S.videoURL);
    S.videoURL = URL.createObjectURL(file); S.fileName = file.name.replace(/\.[^.]+$/, '');
    $('uploadMsg').hidden = true;
    $('fileFacts').hidden = false; $('factName').textContent = file.name; $('factLen').textContent = 'Opening…'; $('factRes').textContent = '—';
    const box = $('videoEmpty'); box.hidden = false;
    box.querySelector('p').textContent = 'Opening ' + file.name + '…';
    box.querySelector('span').textContent = '';
    let ready = false;
    const finish = () => {
      if (ready) return;
      if (!video.videoWidth) { videoProblem(`The browser opened “${file.name}” but cannot decode its picture (often HEVC/H.265 from a phone). ${FORMAT_HELP}`); return; }
      ready = true; clearTimeout(S.loadTimer);
      S.source = 'video'; S.frames = null; S.td = null; S.score = null; pathCache = null;
      S.duration = video.duration;
      S.corners = defaultCorners(); updateHomography();
      $('videoEmpty').hidden = true;
      $('rangeStart').value = 0; $('rangeEnd').value = video.duration.toFixed(1);
      $('analyzeBtn').disabled = false; $('calibBtn').disabled = false;
      $('sourceTag').textContent = file.name;
      $('factLen').textContent = fmt(video.duration); $('factRes').textContent = `${video.videoWidth} × ${video.videoHeight}`;
      $('scrub').max = S.duration.toFixed(2); $('durLabel').textContent = '/ ' + fmt(S.duration);
      $('countAuto').textContent = 'Auto';
      setStatus('Fit the floor corners, then run the analysis.');
      S.cursor = 0; video.currentTime = 0;
      renderLegend(); renderStats(); renderScore();
      setStep('analyze'); setCalibrating(true);
    };
    video.onloadedmetadata = () => {
      // recordings from some phones and screen recorders report an unknown length until the end is reached
      if (!isFinite(video.duration)) {
        const fix = () => { if (isFinite(video.duration)) { video.removeEventListener('durationchange', fix); finish(); } };
        video.addEventListener('durationchange', fix);
        video.currentTime = 1e9;
        return;
      }
      if (video.videoWidth) finish();
      else video.addEventListener('loadeddata', finish, { once: true });
    };
    video.onerror = () => {
      const code = video.error && video.error.code;
      videoProblem(code === 4 || code === 3
        ? `This browser can’t play “${file.name}” (${ext.toUpperCase() || 'unknown'} format or codec). ${FORMAT_HELP}`
        : `“${file.name}” could not be read. Try copying it to your computer first, then choose it again.`);
    };
    clearTimeout(S.loadTimer);
    S.loadTimer = setTimeout(() => { if (!ready) videoProblem(`“${file.name}” is taking too long to open. ${FORMAT_HELP}`); }, 15000);
    video.src = S.videoURL; video.muted = true; video.load();
  }
  $('file').addEventListener('change', e => { loadVideo(e.target.files[0]); e.target.value = ''; });
  [$('stageWrap'), $('dropzone')].forEach(el => {
    ['dragenter', 'dragover'].forEach(n => el.addEventListener(n, e => { e.preventDefault(); el.classList.add('drop'); }));
    ['dragleave', 'drop'].forEach(n => el.addEventListener(n, e => { e.preventDefault(); el.classList.remove('drop'); }));
    el.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) loadVideo(f); });
  });
  $('demoBtn').addEventListener('click', () => { loadDemo(); setStep('map'); });

  // ---------- analysis ----------
  // Two engines: WebGPU (graphics card) where the browser offers it and the runtime can load,
  // otherwise the CPU (WebAssembly) engine. The model accepts any input size that is a multiple of 32.
  const ORT_VER = '1.30.0', ORT_CDN = `https://cdn.jsdelivr.net/npm/onnxruntime-web@${ORT_VER}/dist/`;
  const sessions = {};
  let modelBuf = null;
  function setStatus(s) { $('status').textContent = s; }
  async function getModel() {
    if (modelBuf) return modelBuf;
    setStatus('Loading the person detector (about 13 MB, first run only)…');
    // the model ships as yolov8n.onnx.wasm on hosts that only serve web file types; plain .onnx elsewhere
    let res = await fetch(new URL('yolov8n.onnx.wasm', document.baseURI).href).catch(() => null);
    if (!res || !res.ok) res = await fetch(new URL('yolov8n.onnx', document.baseURI).href);
    if (!res.ok) throw new Error('model ' + res.status);
    modelBuf = await res.arrayBuffer();
    return modelBuf;
  }
  async function makeSession(kind) {
    if (sessions[kind]) return sessions[kind];
    const p = (async () => {
      if (kind === 'gpu') {
        if (!navigator.gpu || !(await navigator.gpu.requestAdapter().catch(() => null))) throw new Error('no webgpu');
        const ort = await import(ORT_CDN + 'ort.webgpu.bundle.min.mjs');
        ort.env.wasm.numThreads = 1;
        ort.env.wasm.wasmPaths = ORT_CDN;
        const buf = await getModel();
        setStatus('Preparing the graphics-card engine…');
        const s = await ort.InferenceSession.create(buf.slice(0), { executionProviders: ['webgpu'] });
        return { ort, s, kind };
      }
      const ort = await import(ORT_CDN + 'ort.wasm.bundle.min.mjs');
      ort.env.wasm.numThreads = 1;
      ort.env.wasm.wasmPaths = { wasm: new URL('ort-wasm-simd-threaded.wasm', document.baseURI).href };
      const buf = await getModel();
      const s = await ort.InferenceSession.create(buf.slice(0), { executionProviders: ['wasm'] });
      return { ort, s, kind };
    })();
    sessions[kind] = p;
    try { return await p; } catch (e) { delete sessions[kind]; throw e; }
  }
  async function getSession(size) {
    if (S.engine !== 'cpu') {
      try {
        const g = await makeSession('gpu');
        // one warm-up run at the chosen size, so a broken GPU path falls back before the real work
        const x = new Float32Array(3 * size * size);
        await g.s.run({ [g.s.inputNames[0]]: new g.ort.Tensor('float32', x, [1, 3, size, size]) });
        S.engine = 'gpu'; return g;
      } catch (e) { console.warn('WebGPU unavailable, using CPU', e); S.engine = 'cpu'; }
    }
    return makeSession('cpu');
  }
  function seekVideo(t) {
    return new Promise(res => {
      const done = () => { video.removeEventListener('seeked', done); clearTimeout(to); res(); };
      const to = setTimeout(done, 3000);
      video.addEventListener('seeked', done);
      video.currentTime = t;
    });
  }
  async function analyze() {
    if (S.analyzing) { S.cancel = true; return; }
    pause(); setCalibrating(false);
    S.analyzing = true; S.cancel = false;
    $('analyzeBtn').querySelector('span').textContent = 'Stop analysis'; $('progress').hidden = false; $('progressBar').style.width = '0%';
    try {
      const size = S.detSize;
      const { ort, s, kind } = await getSession(size);
      const engineName = kind === 'gpu' ? 'graphics card' : 'CPU';
      $('engineLabel').textContent = kind === 'gpu' ? 'Graphics card (WebGPU)' : 'CPU (WebAssembly)';
      const fps = S.fps;
      const t0 = Math.max(0, +$('rangeStart').value || 0), t1 = Math.min(video.duration, +$('rangeEnd').value || video.duration);
      const vw = video.videoWidth, vh = video.videoHeight, sc = Math.min(size / vw, size / vh);
      const lb = { scale: sc, padX: (size - vw * sc) / 2, padY: (size - vh * sc) / 2 };
      const cv = document.createElement('canvas'); cv.width = cv.height = size;
      const cx = cv.getContext('2d', { willReadFrequently: true });
      const input = new Float32Array(3 * size * size);
      const frames = []; const n = Math.max(1, Math.floor((t1 - t0) * fps) + 1);
      const started = performance.now();
      for (let i = 0; i < n && !S.cancel; i++) {
        const t = t0 + i / fps;
        await seekVideo(t);
        cx.fillStyle = 'rgb(114,114,114)'; cx.fillRect(0, 0, size, size);
        cx.drawImage(video, lb.padX, lb.padY, vw * sc, vh * sc);
        const px = cx.getImageData(0, 0, size, size).data;
        for (let j = 0, P = size * size; j < P; j++) { input[j] = px[j * 4] / 255; input[P + j] = px[j * 4 + 1] / 255; input[2 * P + j] = px[j * 4 + 2] / 255; }
        const out = await s.run({ [s.inputNames[0]]: new ort.Tensor('float32', input, [1, 3, size, size]) });
        const data = await out[s.outputNames[0]].getData();
        frames.push({ t, dets: C.decodeYolo(data, lb, 0.3) });
        const el = (performance.now() - started) / 1000, left = el / (i + 1) * (n - i - 1);
        $('progressBar').style.width = ((i + 1) / n * 100).toFixed(1) + '%';
        setStatus(`Frame ${i + 1} of ${n} · ${frames[frames.length - 1].dets.length} people · ${((i + 1) / el).toFixed(1)} frames/s on ${engineName} · about ${Math.ceil(left)} s left`);
        if (i % 4 === 0) drawOverlayDets(frames[frames.length - 1]);
      }
      S.frames = frames;
      if (!frames.length) throw new Error('no frames');
      S.analyzedRange = [t0, t1];
      const secs = ((performance.now() - started) / 1000).toFixed(1);
      retrack(true);
      if (S.td) setStatus(S.cancel ? `Stopped · kept ${frames.length} frames.` : `Done in ${secs} s on ${engineName} · ${frames.length} frames, ${S.td.tracks.length} dancers tracked.`);
    } catch (e) {
      console.error(e);
      setStatus('The person detector could not load. Reload the page and try again.');
    } finally {
      S.analyzing = false; $('analyzeBtn').querySelector('span').textContent = 'Run analysis'; $('progress').hidden = true;
    }
  }
  function drawOverlayDets(f) {
    const { w, h, dpr } = fitCanvas(ov); const R = videoRect();
    octx.setTransform(dpr, 0, 0, dpr, 0, 0); octx.clearRect(0, 0, w, h);
    octx.strokeStyle = cssVar('--cyan'); octx.lineWidth = 1.2;
    f.dets.forEach(d => octx.strokeRect(R.x + d.x1 * R.s, R.y + d.y1 * R.s, (d.x2 - d.x1) * R.s, (d.y2 - d.y1) * R.s));
  }
  $('analyzeBtn').addEventListener('click', analyze);
  function retrack(first) {
    if (!S.frames || !S.H) return;
    const sp = C.stagePoints(S.frames, S.H);
    const auto = C.autoCount(sp);
    const N = $('count').value === 'auto' ? auto : +$('count').value;
    if (!N) { setStatus('No one was found inside the floor area. Check the corner handles.'); toast('No one found inside the floor area.'); return; }
    S.td = C.track(sp, N); pathCache = null;
    if ($('count').value === 'auto') $('countAuto').textContent = `Auto (${auto})`;
    recompose();
    if (first) seek(S.analyzedRange[0]);
  }
  $('count').addEventListener('change', () => { if (S.frames) retrack(); });

  // ---------- sample ----------
  function loadDemo() {
    pause();
    const d = C.demoChoreo();
    S.source = 'demo'; S.td = d.td; S.frames = null; S.duration = d.duration; pathCache = null;
    S.names = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']; S.inst = [0, 1, 2, 3, 4, 5, 6, 7];
    $('bpm').value = d.bpm; $('offset').value = 0;
    video.removeAttribute('src'); video.load();
    $('videoEmpty').hidden = false; $('fileFacts').hidden = true;
    $('analyzeBtn').disabled = true; $('calibBtn').disabled = true; setCalibrating(false);
    $('sourceTag').textContent = 'Sample choreography';
    setStatus('Upload a video to analyze it. The sample needs no analysis.');
    S.cursor = 0;
    recompose();
  }

  // ---------- inspector content ----------
  function renderLegend() {
    const ul = $('legend'); ul.innerHTML = '';
    if (!S.td) { ul.innerHTML = '<li class="note" style="display:block">Voices appear after analysis.</li>'; return; }
    S.names.forEach((n, k) => {
      const li = document.createElement('li');
      li.innerHTML = `<span class="dot" style="--c:${DANCER_COLORS[k % 12]}"></span>
        <input type="text" id="name${k}" aria-label="Dancer ${k + 1} name" maxlength="16">
        <select id="inst${k}" aria-label="Dancer ${k + 1} timbre">${INSTRUMENTS.map((x, i) => `<option value="${i}">${x.name}</option>`).join('')}</select>`;
      li.querySelector('input').value = n;
      li.querySelector('select').value = S.inst[k];
      li.querySelector('input').addEventListener('change', e => { S.names[k] = e.target.value.trim() || `Dancer ${k + 1}`; buildXML(); S.loadedXML = null; renderScore(); });
      li.querySelector('select').addEventListener('change', e => { S.inst[k] = +e.target.value; buildEvents(); buildXML(); renderScore(); });
      ul.appendChild(li);
    });
  }
  function renderStats() {
    const dl = $('stats'), kinds = $('kinds');
    if (!S.score) { dl.innerHTML = '<div><dt>Nothing composed yet</dt><dd></dd></div>'; kinds.innerHTML = ''; return; }
    const sc = S.score, nNotes = sc.melodies.reduce((a, m) => a + m.length, 0);
    const rows = [['Dancers', sc.melodies.length], ['Bars', sc.nSteps / 8], ['Notes in voices', nNotes], ['Chord changes', sc.chords.length], ['Length', fmt(S.duration)]];
    dl.innerHTML = rows.map(r => `<div><dt>${r[0]}</dt><dd class="num">${r[1]}</dd></div>`).join('');
    const tot = sc.chords.reduce((a, c) => a + c.dur, 0) || 1, by = {};
    sc.chords.forEach(c => by[c.kind] = (by[c.kind] || 0) + c.dur);
    kinds.innerHTML = Object.keys(CHORD_KIND).map(k => {
      const p = Math.round((by[k] || 0) / tot * 100);
      return `<li><span>${CHORD_KIND[k]}</span><span class="pct num">${p}%</span><span class="bar"><i style="width:${p}%"></i></span></li>`;
    }).join('');
  }

  // ---------- score (OpenSheetMusicDisplay) ----------
  function measuresTotal() { return S.score ? S.score.nSteps / 8 : 0; }
  let renderToken = 0;
  async function renderScore() {
    const box = $('score');
    if (!S.score) { box.innerHTML = ''; S.osmd = null; S.loadedXML = null; S.cursorIdx = null; $('scoreEmpty').hidden = false; $('pageLabel').textContent = '—'; return; }
    $('scoreEmpty').hidden = true;
    S.perPage = window.innerWidth < 720 ? 2 : 4;
    const total = measuresTotal();
    S.page = Math.min(S.page, Math.max(0, Math.ceil(total / S.perPage) - 1));
    const from = S.page * S.perPage + 1, to = Math.min(total, from + S.perPage - 1);
    $('pageLabel').textContent = `Bars ${from}–${to} of ${total}`;
    if (S.view !== 'score') return;
    if (!window.opensheetmusicdisplay) { box.innerHTML = '<p class="note score-empty">The score renderer did not load. Export the MusicXML file to open it in MuseScore.</p>'; return; }
    const tok = ++renderToken;
    try {
      if (!S.osmd) {
        const ink = '#d9dae6';
        S.osmd = new opensheetmusicdisplay.OpenSheetMusicDisplay(box, {
          autoResize: false, backend: 'svg', drawTitle: false, drawSubtitle: false, drawComposer: false, drawCredits: false,
          drawPartNames: true, drawMeasureNumbers: true, drawingParameters: 'compacttight',
          defaultColorMusic: ink, defaultColorNotehead: ink, defaultColorStem: ink, defaultColorRest: ink, defaultColorLabel: '#a2a6bd', defaultColorTitle: ink
        });
      }
      if (S.loadedXML !== S.xml) { await S.osmd.load(S.xml); S.loadedXML = S.xml; }
      if (tok !== renderToken) return;
      S.osmd.setOptions({ drawFromMeasureNumber: from, drawUpToMeasureNumber: to });
      S.osmd.zoom = window.innerWidth < 720 ? 0.5 : 0.62;
      S.osmd.render();
      buildCursorIndex(from, to);
    } catch (e) { console.error(e); box.innerHTML = '<p class="note score-empty">These bars could not be drawn.</p>'; }
  }
  // Playback cursor on the score: for every rendered bar, map beat position to x by interpolating
  // between the note and rest positions OSMD laid out. Hidden if OSMD's layout can't be read.
  function buildCursorIndex(from, to) {
    S.cursorIdx = null;
    try {
      const unit = 10 * S.osmd.zoom, idx = {};
      S.osmd.GraphicSheet.MeasureList.forEach(staves => {
        const ms = (staves || []).filter(Boolean); if (!ms.length) return;
        const num = ms[0].MeasureNumber; if (num < from || num > to) return;
        const first = ms[0].PositionAndShape, last = ms[ms.length - 1].PositionAndShape;
        const pts = new Map();
        ms.forEach(gm => (gm.staffEntries || []).forEach(se => {
          const ts = se.relInMeasureTimestamp.RealValue, x = se.PositionAndShape.AbsolutePosition.x;
          if (!pts.has(ts) || x < pts.get(ts)) pts.set(ts, x);
        }));
        const arr = Array.from(pts.entries()).sort((a, b) => a[0] - b[0]);
        if (!arr.length) return;
        const endX = first.AbsolutePosition.x + first.Size.width;
        arr.push([1, endX - 0.6]);
        idx[num] = {
          pts: arr.map(([ts, x]) => [ts, x * unit]),
          top: (first.AbsolutePosition.y - 1.5) * unit,
          bottom: (last.AbsolutePosition.y + 5.5) * unit
        };
      });
      if (Object.keys(idx).length) S.cursorIdx = idx;
    } catch (e) { console.warn('score cursor unavailable', e); }
  }
  function placeCursor(t) {
    const el = $('scoreCursor');
    if (!S.score || !S.cursorIdx || S.view !== 'score') { el.hidden = true; return; }
    const s = S.score.settings, pos = (t - s.offset) / S.score.stepDur / 8;
    const meas = Math.floor(pos) + 1, frac = pos - Math.floor(pos), m = S.cursorIdx[meas];
    if (pos < 0 || !m) { el.hidden = true; return; }
    const P = m.pts; let x = P[0][1];
    for (let i = 0; i < P.length - 1; i++) {
      if (frac >= P[i][0] && frac <= P[i + 1][0]) { const u = (frac - P[i][0]) / Math.max(1e-6, P[i + 1][0] - P[i][0]); x = P[i][1] + (P[i + 1][1] - P[i][1]) * u; break; }
    }
    el.hidden = false;
    el.style.left = x + 'px'; el.style.top = m.top + 'px'; el.style.height = (m.bottom - m.top) + 'px';
    if (S.playing) {
      const paper = $('scorePaper');
      if (x < paper.scrollLeft + 20 || x > paper.scrollLeft + paper.clientWidth - 40) paper.scrollLeft = Math.max(0, x - 60);
      if (m.top < paper.scrollTop || m.bottom > paper.scrollTop + paper.clientHeight) paper.scrollTop = Math.max(0, m.top - 10);
    }
  }
  $('prevPage').addEventListener('click', () => { if (S.page > 0) { S.page--; renderScore(); } });
  $('nextPage').addEventListener('click', () => { if ((S.page + 1) * S.perPage < measuresTotal()) { S.page++; renderScore(); } });
  let rz; window.addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(renderScore, 250); });

  // ---------- export (unchanged contents) ----------
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(b) { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
  function zip(files) {
    const enc = new TextEncoder(), chunks = [], cen = []; let off = 0;
    const u16 = v => [v & 255, (v >> 8) & 255], u32 = v => [v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];
    files.forEach(f => {
      const name = enc.encode(f.name), data = typeof f.data === 'string' ? enc.encode(f.data) : f.data, crc = crc32(data);
      const head = [0x50, 0x4b, 3, 4, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0)];
      chunks.push(new Uint8Array(head), name, data);
      cen.push([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(off)], name);
      off += head.length + name.length + data.length;
    });
    let cenLen = 0; cen.forEach(c => { const a = c instanceof Uint8Array ? c : new Uint8Array(c); chunks.push(a); cenLen += a.length; });
    chunks.push(new Uint8Array([0x50, 0x4b, 5, 6, 0, 0, 0, 0, ...u16(files.length), ...u16(files.length), ...u32(cenLen), ...u32(off), 0, 0]));
    return new Blob(chunks, { type: 'application/zip' });
  }
  let dlCap = undefined;
  async function downloadsCap() {
    if (dlCap !== undefined) return dlCap;
    try { dlCap = window.claude && window.claude.use ? await window.claude.use('downloads') : null; } catch (e) { dlCap = null; }
    return dlCap;
  }
  async function saveFile(name, blob) {
    const dl = await downloadsCap();
    if (dl) {
      try { await dl.save({ filename: name, data: blob }); toast('Saved.'); }
      catch (e) { if (e && e.code !== 'declined') toast('Files can’t be saved from this view.'); }
      return;
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  function exportFiles() {
    const base = (S.source === 'demo' ? 'sample' : (S.fileName || 'formation')).replace(/[^\w\uAC00-\uD7A3-]+/g, '_');
    return {
      base,
      musicxml: { name: `${base}.musicxml`, data: S.xml },
      mid: { name: `${base}.mid`, data: C.toMIDI(parts(), settings().bpm) },
      csv: { name: `${base}_positions.csv`, data: C.tracksCSV(S.td, S.names) }
    };
  }
  $('exportBtn').addEventListener('click', () => {
    if (!S.score) { toast('Nothing to export yet.'); return; }
    const f = exportFiles();
    saveFile(`${f.base}_score.zip`, zip([f.musicxml, f.mid, f.csv]));
  });
  $$('[data-single]').forEach(b => b.addEventListener('click', () => {
    if (!S.score) return;
    const f = exportFiles()[b.dataset.single];
    saveFile(f.name, new Blob([f.data]));
  }));
  // single files only where the host allows any extension (standalone hosting)
  downloadsCap().then(dl => { $('singleFiles').hidden = !!dl; });

  // ---------- controls ----------
  $('playBtn').addEventListener('click', () => S.playing ? pause() : play());
  $('startBtn').addEventListener('click', () => seek(0));
  $('scrub').addEventListener('input', e => seek(+e.target.value));
  ['bpm', 'offset', 'key', 'mode', 'span'].forEach(id => $(id).addEventListener('change', () => { const was = S.playing; if (was) pause(); recompose(); if (was) play(); }));
  $('origAudio').addEventListener('change', e => { video.muted = !e.target.checked; });
  $('setBeat').addEventListener('click', () => { $('offset').value = now().toFixed(2); $('offset').dispatchEvent(new Event('change')); });
  let taps = [];
  $('tapBtn').addEventListener('click', () => {
    const t = performance.now() / 1000; taps = taps.filter(x => t - x < 3).concat(t);
    if (taps.length >= 3) { const iv = (taps[taps.length - 1] - taps[0]) / (taps.length - 1); $('bpm').value = Math.round(60 / iv); $('bpm').dispatchEvent(new Event('change')); }
    $('tapBtn').querySelector('span').textContent = taps.length < 3 ? `Tap ${taps.length}/3` : 'Tap';
  });
  document.addEventListener('keydown', e => {
    if (e.code === 'Space' && !/INPUT|SELECT|TEXTAREA|BUTTON/.test(e.target.tagName)) { e.preventDefault(); S.playing ? pause() : play(); }
    if (e.key === 'Escape' && !$('typeDialog').hidden) closeType();
  });

  // ---------- typeface settings ----------
  const UI_PRESETS = ['Geist', 'IBM Plex Sans', 'Hanken Grotesk', 'Schibsted Grotesk', 'Onest', 'Instrument Sans'];
  const MONO_PRESETS = ['Geist Mono', 'IBM Plex Mono', 'JetBrains Mono', 'DM Mono', 'Fragment Mono'];
  const FALLBACK = { ui: '"Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", system-ui, sans-serif', mono: 'ui-monospace, "SF Mono", Menlo, monospace' };
  const T = { ui: { preset: 'Geist', local: '', file: '' }, mono: { preset: 'Geist Mono', local: '', file: '' } };
  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
  };
  function idb() {
    return new Promise((res, rej) => {
      try { const r = indexedDB.open('formation-score-fonts', 1); r.onupgradeneeded = () => r.result.createObjectStore('files'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }
      catch (e) { rej(e); }
    });
  }
  async function idbPut(key, val) { try { const db = await idb(); db.transaction('files', 'readwrite').objectStore('files').put(val, key); } catch (e) { } }
  async function idbGet(key) { try { const db = await idb(); return await new Promise(r => { const q = db.transaction('files').objectStore('files').get(key); q.onsuccess = () => r(q.result); q.onerror = () => r(null); }); } catch (e) { return null; } }
  async function idbDel(key) { try { const db = await idb(); db.transaction('files', 'readwrite').objectStore('files').delete(key); } catch (e) { } }
  const loadedPresets = new Set(['Geist', 'Geist Mono']);
  function loadPreset(name, mono) {
    if (loadedPresets.has(name)) return;
    loadedPresets.add(name);
    const l = document.createElement('link'); l.rel = 'stylesheet';
    l.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(name).replace(/%20/g, '+')}:wght@400;500${mono ? '' : ';600'}&display=swap`;
    document.head.appendChild(l);
  }
  function applyType() {
    ['ui', 'mono'].forEach(k => {
      const t = T[k], fam = [];
      if (t.file) fam.push(`"FS-User-${k}"`);
      if (t.local) fam.push(`"${t.local.replace(/"/g, '')}"`);
      fam.push(`"${t.preset}"`);
      loadPreset(t.preset, k === 'mono');
      document.documentElement.style.setProperty(k === 'ui' ? '--font-ui' : '--font-mono', fam.join(', ') + ', ' + FALLBACK[k]);
      $(k + 'FontNow').textContent = 'Now: ' + (t.file ? t.file + ' (file)' : t.local ? t.local + ' (installed)' : t.preset) + ' · 0123456789 C♯4';
    });
    store.set('fs-type', { ui: { preset: T.ui.preset, local: T.ui.local, file: T.ui.file }, mono: { preset: T.mono.preset, local: T.mono.local, file: T.mono.file } });
    S.loadedXML = null;
  }
  async function useFontFile(k, name, buf) {
    try {
      const face = new FontFace(`FS-User-${k}`, buf);
      await face.load(); document.fonts.add(face);
      T[k].file = name; applyType(); return true;
    } catch (e) { toast('That file could not be read as a font. Try .woff2, .otf or .ttf.'); return false; }
  }
  function initType() {
    $('uiFontPreset').innerHTML = UI_PRESETS.map(n => `<option>${n}</option>`).join('');
    $('monoFontPreset').innerHTML = MONO_PRESETS.map(n => `<option>${n}</option>`).join('');
    const saved = store.get('fs-type');
    if (saved) ['ui', 'mono'].forEach(k => { if (saved[k]) { T[k].preset = saved[k].preset || T[k].preset; T[k].local = saved[k].local || ''; } });
    ['ui', 'mono'].forEach(k => {
      $(k + 'FontPreset').value = T[k].preset; $(k + 'FontLocal').value = T[k].local;
      $(k + 'FontPreset').addEventListener('change', e => { T[k].preset = e.target.value; applyType(); });
      $(k + 'FontLocal').addEventListener('change', e => { T[k].local = e.target.value.trim(); applyType(); });
      $(k + 'FontFile').addEventListener('change', async e => {
        const f = e.target.files[0]; if (!f) return;
        const buf = await f.arrayBuffer();
        if (await useFontFile(k, f.name, buf.slice(0))) idbPut(k, { name: f.name, buf });
        e.target.value = '';
      });
      if (saved && saved[k] && saved[k].file) idbGet(k).then(v => { if (v && v.buf) useFontFile(k, v.name, v.buf); });
    });
    applyType();
  }
  function openType() { $('typeDialog').hidden = false; $('uiFontPreset').focus(); }
  function closeType() { $('typeDialog').hidden = true; $('typeBtn').focus(); }
  $('typeBtn').addEventListener('click', openType);
  $('typeClose').addEventListener('click', closeType);
  $('typeOk').addEventListener('click', closeType);
  $('typeDialog').addEventListener('click', e => { if (e.target === $('typeDialog')) closeType(); });
  $('typeReset').addEventListener('click', () => {
    T.ui = { preset: 'Geist', local: '', file: '' }; T.mono = { preset: 'Geist Mono', local: '', file: '' };
    ['ui', 'mono'].forEach(k => { $(k + 'FontPreset').value = T[k].preset; $(k + 'FontLocal').value = ''; idbDel(k); });
    applyType();
  });

  // ---------- frame loop ----------
  function frame() {
    const t = now();
    if (!S.playing && S.source === 'video' && !S.analyzing && video.readyState >= 1 && Math.abs(video.currentTime - S.cursor) > 0.05 && !video.seeking) video.currentTime = S.cursor;
    drawMap(t);
    drawFeats(t);
    if (S.view === 'roll') drawRoll();
    placeCursor(t);
    if (!S.analyzing) drawOverlay(t);
    $('timeLabel').textContent = fmt(t);
    if (document.activeElement !== $('scrub')) $('scrub').value = t;
    if (S.score) {
      const s = S.score.settings, step = Math.floor((t - s.offset) / S.score.stepDur);
      const meas = step >= 0 ? Math.floor(step / 8) + 1 : 0;
      $('measureLabel').textContent = meas > 0 ? `Bar ${meas} · ${Math.floor((step % 8) / 2) + 1}` : 'Pickup';
      const ch = S.score.chords.find(c => step >= c.start && step < c.start + c.dur);
      $('chordKind').textContent = ch ? CHORD_KIND[ch.kind] : '—';
      $('chordNotes').textContent = ch ? ch.notes.map(m => NOTE_NAMES[m % 12]).join(' ') : '';
      if (S.playing && meas > 0 && S.view === 'score') {
        const pg = Math.floor((meas - 1) / S.perPage);
        if (pg !== S.page && pg * S.perPage < measuresTotal()) { S.page = pg; renderScore(); }
      }
    } else { $('measureLabel').textContent = '—'; $('chordKind').textContent = '—'; $('chordNotes').textContent = ''; }
    requestAnimationFrame(frame);
  }

  initType();
  initMap();
  loadDemo();
  setStep('upload');
  requestAnimationFrame(frame);
})();
